import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { User, UserRole, PlanType } from '../types';

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  theme: 'dark' | 'light';
  login: (email: string, password: string, role?: UserRole) => Promise<boolean>;
  register: (name: string, email: string, password: string, role: UserRole) => Promise<boolean>;
  logout: () => void;
  toggleTheme: () => void;
  updatePlan: (plan: PlanType) => void;
}

const mockUsers: User[] = [
  {
    id: 'user-1',
    email: 'candidate@demo.com',
    name: 'Alex Johnson',
    role: 'candidate',
    plan: 'pro',
    avatar: '',
    createdAt: '2024-01-15',
    scansUsed: 3,
    scansLimit: -1,
  },
  {
    id: 'user-2',
    email: 'recruiter@demo.com',
    name: 'Sarah Mitchell',
    role: 'recruiter',
    plan: 'recruiter',
    avatar: '',
    createdAt: '2024-01-10',
    scansUsed: 45,
    scansLimit: -1,
  },
  {
    id: 'user-3',
    email: 'admin@demo.com',
    name: 'Admin User',
    role: 'admin',
    plan: 'pro',
    avatar: '',
    createdAt: '2023-12-01',
    scansUsed: 0,
    scansLimit: -1,
  },
];

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      isAuthenticated: false,
      theme: 'dark',

      login: async (email: string, _password: string, role?: UserRole) => {
        // Demo login - accept any password
        const foundUser = mockUsers.find(u => u.email === email) ||
          (role ? { 
            id: `user-${Date.now()}`,
            email, 
            name: email.split('@')[0].replace('.', ' '),
            role: role || 'candidate' as UserRole,
            plan: 'free' as PlanType,
            avatar: '',
            createdAt: new Date().toISOString(),
            scansUsed: 0,
            scansLimit: 3,
          } : null);

        if (foundUser) {
          set({ user: foundUser, isAuthenticated: true });
          return true;
        }
        return false;
      },

      register: async (name: string, email: string, _password: string, role: UserRole) => {
        const newUser: User = {
          id: `user-${Date.now()}`,
          email,
          name,
          role,
          plan: 'free',
          avatar: '',
          createdAt: new Date().toISOString(),
          scansUsed: 0,
          scansLimit: 3,
        };
        set({ user: newUser, isAuthenticated: true });
        return true;
      },

      logout: () => {
        set({ user: null, isAuthenticated: false });
      },

      toggleTheme: () => {
        const current = get().theme;
        set({ theme: current === 'dark' ? 'light' : 'dark' });
      },

      updatePlan: (plan: PlanType) => {
        const user = get().user;
        if (user) {
          set({ user: { ...user, plan, scansLimit: plan === 'free' ? 3 : -1 } });
        }
      },
    }),
    { name: 'auth-store' }
  )
);
