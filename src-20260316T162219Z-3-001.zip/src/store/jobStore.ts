import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { JobDescription, JobMatch, ResumeAnalysis } from '../types';

interface JobState {
  jobs: JobDescription[];
  jobMatches: JobMatch[];
  isMatching: boolean;
  addJob: (job: Omit<JobDescription, 'id' | 'postedAt'>) => JobDescription;
  analyzeJobMatch: (resume: ResumeAnalysis, jobDescription: string) => Promise<JobMatch>;
  clearMatches: () => void;
}

export const mockJobs: JobDescription[] = [
  {
    id: 'job-1',
    title: 'Senior Frontend Engineer',
    company: 'Meta',
    description: 'Build next-generation user interfaces for billions of users worldwide.',
    requiredSkills: ['React', 'TypeScript', 'JavaScript', 'CSS', 'GraphQL'],
    preferredSkills: ['Next.js', 'Redux', 'Webpack', 'Testing'],
    experienceLevel: '5+ years',
    location: 'Menlo Park, CA (Remote)',
    salary: '$180k - $240k',
    postedAt: '2024-02-10',
    postedBy: 'user-2',
  },
  {
    id: 'job-2',
    title: 'Full Stack Developer',
    company: 'Stripe',
    description: 'Help build the economic infrastructure of the internet.',
    requiredSkills: ['React', 'Node.js', 'TypeScript', 'PostgreSQL', 'REST API'],
    preferredSkills: ['AWS', 'Docker', 'Kubernetes', 'Python'],
    experienceLevel: '3+ years',
    location: 'San Francisco, CA',
    salary: '$160k - $200k',
    postedAt: '2024-02-12',
    postedBy: 'user-2',
  },
  {
    id: 'job-3',
    title: 'Software Engineer II',
    company: 'Google',
    description: 'Create elegant solutions to complex engineering challenges.',
    requiredSkills: ['Python', 'Java', 'Data Structures', 'Algorithms', 'Git'],
    preferredSkills: ['Kubernetes', 'TensorFlow', 'Go', 'GCP'],
    experienceLevel: '2+ years',
    location: 'Mountain View, CA',
    salary: '$170k - $220k',
    postedAt: '2024-02-08',
    postedBy: 'user-2',
  },
  {
    id: 'job-4',
    title: 'React Native Developer',
    company: 'Airbnb',
    description: 'Build mobile experiences used by millions of travelers.',
    requiredSkills: ['React Native', 'JavaScript', 'TypeScript', 'iOS', 'Android'],
    preferredSkills: ['Redux', 'GraphQL', 'CI/CD', 'Testing'],
    experienceLevel: '2+ years',
    location: 'Remote',
    salary: '$140k - $180k',
    postedAt: '2024-02-14',
  },
  {
    id: 'job-5',
    title: 'Backend Engineer',
    company: 'Shopify',
    description: 'Scale systems that power commerce for millions of merchants.',
    requiredSkills: ['Ruby on Rails', 'Node.js', 'PostgreSQL', 'Redis', 'Docker'],
    preferredSkills: ['Kubernetes', 'AWS', 'GraphQL', 'MySQL'],
    experienceLevel: '3+ years',
    location: 'Remote',
    salary: '$150k - $190k',
    postedAt: '2024-02-11',
  },
];

const calculateJobMatch = (resume: ResumeAnalysis, job: JobDescription): JobMatch => {
  const resumeSkillNames = resume.skills.map(s => s.name.toLowerCase());
  const requiredLower = job.requiredSkills.map(s => s.toLowerCase());
  const preferredLower = job.preferredSkills.map(s => s.toLowerCase());

  const matchedRequired = requiredLower.filter(s => resumeSkillNames.includes(s));
  const matchedPreferred = preferredLower.filter(s => resumeSkillNames.includes(s));
  const allMatched = [...new Set([...matchedRequired, ...matchedPreferred])];

  const skillMatchPercent = Math.round(
    ((matchedRequired.length / requiredLower.length) * 0.7 +
     (matchedPreferred.length / Math.max(preferredLower.length, 1)) * 0.3) * 100
  );

  const missingRequired = requiredLower.filter(s => !resumeSkillNames.includes(s));
  const overallScore = Math.min(95, Math.max(45, skillMatchPercent + Math.floor(Math.random() * 15)));

  return {
    jobId: job.id,
    job,
    overallScore,
    skillMatchPercent,
    experienceMatchPercent: Math.floor(Math.random() * 30) + 65,
    missingSkills: missingRequired,
    matchedSkills: allMatched,
    suggestions: [
      `Add ${missingRequired[0] || 'more relevant'} experience to strengthen application`,
      'Tailor your resume summary to match this role',
      'Include quantifiable achievements from similar projects',
    ],
  };
};

export const useJobStore = create<JobState>()(
  persist(
    (set, get) => ({
      jobs: mockJobs,
      jobMatches: [],
      isMatching: false,

      addJob: (jobData) => {
        const job: JobDescription = {
          ...jobData,
          id: `job-${Date.now()}`,
          postedAt: new Date().toISOString(),
        };
        set({ jobs: [job, ...get().jobs] });
        return job;
      },

      analyzeJobMatch: async (resume: ResumeAnalysis, _jobDescription: string) => {
        set({ isMatching: true });
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        const bestJob = get().jobs[0];
        const match = calculateJobMatch(resume, bestJob);
        const matches = [match, ...get().jobMatches].slice(0, 20);
        set({ jobMatches: matches, isMatching: false });
        return match;
      },

      clearMatches: () => set({ jobMatches: [] }),
    }),
    { name: 'job-store' }
  )
);

export const getTopJobMatches = (resume: ResumeAnalysis, jobs: JobDescription[]): JobMatch[] => {
  return jobs
    .map(job => calculateJobMatch(resume, job))
    .sort((a, b) => b.overallScore - a.overallScore)
    .slice(0, 5);
};
