import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { ResumeAnalysis, ExtractedSkill } from '../types';

interface ResumeState {
  analyses: ResumeAnalysis[];
  currentAnalysis: ResumeAnalysis | null;
  isAnalyzing: boolean;
  uploadFile: (file: File, userId: string) => Promise<ResumeAnalysis>;
  setCurrentAnalysis: (analysis: ResumeAnalysis | null) => void;
  clearHistory: () => void;
}

const generateMockAnalysis = (fileName: string, userId: string): ResumeAnalysis => {
  const skills: ExtractedSkill[] = [
    { name: 'React', category: 'technical', level: 'advanced', yearsOfExp: 3 },
    { name: 'TypeScript', category: 'technical', level: 'advanced', yearsOfExp: 2 },
    { name: 'Node.js', category: 'technical', level: 'intermediate', yearsOfExp: 2 },
    { name: 'Python', category: 'technical', level: 'intermediate', yearsOfExp: 1 },
    { name: 'AWS', category: 'tool', level: 'beginner', yearsOfExp: 1 },
    { name: 'Docker', category: 'tool', level: 'intermediate', yearsOfExp: 1 },
    { name: 'Git', category: 'tool', level: 'advanced', yearsOfExp: 3 },
    { name: 'Communication', category: 'soft', level: 'advanced' },
    { name: 'Leadership', category: 'soft', level: 'intermediate' },
    { name: 'Problem Solving', category: 'soft', level: 'expert' },
  ];

  return {
    id: `analysis-${Date.now()}`,
    userId,
    fileName,
    uploadedAt: new Date().toISOString(),
    overallScore: Math.floor(Math.random() * 20) + 72,
    skillMatchPercent: Math.floor(Math.random() * 20) + 68,
    keywordDensityPercent: Math.floor(Math.random() * 25) + 55,
    atsScore: Math.floor(Math.random() * 15) + 78,
    skills,
    experience: [
      {
        company: 'TechCorp Inc.',
        title: 'Software Engineer',
        duration: '2022 – Present',
        description: 'Built scalable React applications with TypeScript. Led team of 3 engineers.',
        skills: ['React', 'TypeScript', 'AWS'],
      },
      {
        company: 'StartupXYZ',
        title: 'Frontend Developer',
        duration: '2021 – 2022',
        description: 'Developed and maintained responsive web applications.',
        skills: ['React', 'JavaScript', 'CSS'],
      },
    ],
    education: [
      {
        institution: 'State University',
        degree: 'Bachelor of Science',
        field: 'Computer Science',
        year: '2021',
        gpa: '3.8',
      },
    ],
    projects: [
      {
        name: 'E-Commerce Platform',
        description: 'Full-stack e-commerce solution with React & Node.js',
        technologies: ['React', 'Node.js', 'PostgreSQL'],
        link: 'https://github.com',
      },
    ],
    certifications: ['AWS Certified Developer', 'Google Cloud Professional'],
    missingKeywords: ['GraphQL', 'Kubernetes', 'Machine Learning', 'CI/CD', 'Agile/Scrum', 'REST API'],
    atsIssues: [
      { type: 'warning', message: 'Resume uses tables/columns', suggestion: 'Use single-column format for better ATS parsing' },
      { type: 'info', message: 'Missing LinkedIn URL', suggestion: 'Add your LinkedIn profile URL in the contact section' },
      { type: 'critical', message: 'No quantified achievements', suggestion: 'Add metrics: "Increased performance by 40%"' },
    ],
    suggestions: [
      { section: 'Summary', priority: 'high', issue: 'No professional summary', recommendation: 'Add a 2-3 sentence professional summary highlighting key achievements' },
      { section: 'Skills', priority: 'medium', issue: 'Skills not categorized', recommendation: 'Group skills by category: Technical, Tools, Soft Skills' },
      { section: 'Experience', priority: 'high', issue: 'Weak action verbs', recommendation: 'Start bullet points with strong action verbs: "Architected", "Optimized", "Delivered"' },
      { section: 'Keywords', priority: 'high', issue: 'Missing industry keywords', recommendation: 'Add: GraphQL, Kubernetes, Microservices, CI/CD Pipeline' },
    ],
    sectionScores: [
      { section: 'Contact Info', score: 90, maxScore: 100, status: 'excellent' },
      { section: 'Summary', score: 40, maxScore: 100, status: 'needs_improvement' },
      { section: 'Experience', score: 75, maxScore: 100, status: 'good' },
      { section: 'Skills', score: 80, maxScore: 100, status: 'good' },
      { section: 'Education', score: 95, maxScore: 100, status: 'excellent' },
      { section: 'Projects', score: 70, maxScore: 100, status: 'good' },
      { section: 'Certifications', score: 85, maxScore: 100, status: 'excellent' },
      { section: 'Keywords', score: 55, maxScore: 100, status: 'needs_improvement' },
    ],
    aiRewrite: `PROFESSIONAL SUMMARY
Innovative Software Engineer with 3+ years of experience building scalable web applications using React and TypeScript. Track record of delivering high-performance solutions that improved user engagement by 40%. Proven leader who mentored junior developers and architected microservice-based solutions at TechCorp Inc.

TECHNICAL SKILLS
• Languages: TypeScript, JavaScript, Python, SQL
• Frontend: React.js, Next.js, Tailwind CSS, Redux
• Backend: Node.js, Express.js, REST APIs
• Cloud & DevOps: AWS (EC2, S3, Lambda), Docker, Git
• Databases: PostgreSQL, MongoDB, Redis`,
  };
};

export const useResumeStore = create<ResumeState>()(
  persist(
    (set, get) => ({
      analyses: [],
      currentAnalysis: null,
      isAnalyzing: false,

      uploadFile: async (file: File, userId: string) => {
        set({ isAnalyzing: true });
        // Simulate AI processing time
        await new Promise(resolve => setTimeout(resolve, 3000));
        const analysis = generateMockAnalysis(file.name, userId);
        const analyses = [analysis, ...get().analyses].slice(0, 10);
        set({ analyses, currentAnalysis: analysis, isAnalyzing: false });
        return analysis;
      },

      setCurrentAnalysis: (analysis) => set({ currentAnalysis: analysis }),

      clearHistory: () => set({ analyses: [], currentAnalysis: null }),
    }),
    { name: 'resume-store' }
  )
);
