import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  LayoutDashboard, FileText, Search, BarChart3, Settings,
  Briefcase, Users, Star, Upload, History, Shield,
  TrendingUp, Bell, ChevronRight, LogOut, HelpCircle
} from 'lucide-react';
import { useAuthStore } from '../../store/authStore';

interface SidebarProps {
  isCollapsed?: boolean;
  onToggle?: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isCollapsed = false, onToggle }) => {
  const { user, logout } = useAuthStore();
  const location = useLocation();

  const candidateLinks = [
    { icon: LayoutDashboard, label: 'Dashboard', href: '/dashboard' },
    { icon: Upload, label: 'Upload Resume', href: '/dashboard/upload' },
    { icon: FileText, label: 'My Resumes', href: '/dashboard/resumes' },
    { icon: Search, label: 'Job Matching', href: '/dashboard/jobs' },
    { icon: BarChart3, label: 'Analytics', href: '/dashboard/analytics' },
    { icon: Star, label: 'AI Rewrite', href: '/dashboard/rewrite' },
    { icon: History, label: 'History', href: '/dashboard/history' },
    { icon: Settings, label: 'Settings', href: '/dashboard/settings' },
  ];

  const recruiterLinks = [
    { icon: LayoutDashboard, label: 'Dashboard', href: '/recruiter' },
    { icon: Briefcase, label: 'Post Jobs', href: '/recruiter/post-job' },
    { icon: Users, label: 'Candidates', href: '/recruiter/candidates' },
    { icon: BarChart3, label: 'AI Ranking', href: '/recruiter/ranking' },
    { icon: TrendingUp, label: 'Analytics', href: '/recruiter/analytics' },
    { icon: Settings, label: 'Settings', href: '/recruiter/settings' },
  ];

  const adminLinks = [
    { icon: LayoutDashboard, label: 'Overview', href: '/admin' },
    { icon: Users, label: 'Users', href: '/admin/users' },
    { icon: BarChart3, label: 'Analytics', href: '/admin/analytics' },
    { icon: Star, label: 'AI Usage', href: '/admin/ai-usage' },
    { icon: Shield, label: 'Subscriptions', href: '/admin/subscriptions' },
    { icon: Settings, label: 'Settings', href: '/admin/settings' },
  ];

  const links = user?.role === 'admin'
    ? adminLinks
    : user?.role === 'recruiter'
    ? recruiterLinks
    : candidateLinks;

  const isActive = (href: string) => location.pathname === href;

  return (
    <motion.aside
      className={`fixed left-0 top-0 h-screen bg-dark-card border-r border-dark-border flex flex-col transition-all duration-300 z-40 ${
        isCollapsed ? 'w-16' : 'w-64'
      }`}
      initial={false}
      animate={{ width: isCollapsed ? 64 : 256 }}
    >
      {/* Logo */}
      <div className="flex items-center gap-3 p-4 h-16 md:h-20 border-b border-dark-border">
        <div className="w-9 h-9 min-w-[36px] rounded-xl bg-gradient-to-br from-primary-500 to-accent-purple flex items-center justify-center shadow-glow">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 2a10 10 0 0 0-3.5 19.3M12 2a10 10 0 0 1 3.5 19.3"/>
            <path d="M12 6v6l4 2"/>
          </svg>
        </div>
        {!isCollapsed && (
          <motion.div
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex flex-col overflow-hidden"
          >
            <span className="text-white font-bold leading-tight text-sm">ResumeAI</span>
            <span className="text-white/40 text-[10px] capitalize">{user?.role} Panel</span>
          </motion.div>
        )}
        {onToggle && (
          <button
            onClick={onToggle}
            className="ml-auto w-7 h-7 rounded-lg hover:bg-white/5 flex items-center justify-center text-white/40 hover:text-white transition-all"
          >
            <ChevronRight size={14} className={`transition-transform ${isCollapsed ? '' : 'rotate-180'}`} />
          </button>
        )}
      </div>

      {/* User Info */}
      {!isCollapsed && user && (
        <div className="p-4 border-b border-dark-border">
          <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5">
            <div className="w-9 h-9 min-w-[36px] rounded-lg bg-gradient-to-br from-primary-500 to-accent-purple flex items-center justify-center text-sm font-bold text-white">
              {user.name[0].toUpperCase()}
            </div>
            <div className="overflow-hidden">
              <p className="text-white text-sm font-semibold truncate">{user.name}</p>
              <span className="text-[10px] bg-primary-500/20 text-primary-400 px-1.5 py-0.5 rounded capitalize">
                {user.plan}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto custom-scroll">
        {links.map((link) => {
          const Icon = link.icon;
          const active = isActive(link.href);
          return (
            <Link
              key={link.href}
              to={link.href}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200 group
                ${active
                  ? 'bg-primary-600/20 text-white border border-primary-500/30'
                  : 'text-white/50 hover:text-white hover:bg-white/5'
                }`}
              title={isCollapsed ? link.label : undefined}
            >
              <Icon size={18} className={`min-w-[18px] ${active ? 'text-primary-400' : 'group-hover:text-primary-400 transition-colors'}`} />
              {!isCollapsed && (
                <motion.span
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-sm font-medium"
                >
                  {link.label}
                </motion.span>
              )}
              {active && !isCollapsed && (
                <div className="ml-auto w-1.5 h-1.5 rounded-full bg-primary-400" />
              )}
            </Link>
          );
        })}
      </nav>

      {/* Bottom Actions */}
      <div className="p-3 border-t border-dark-border space-y-1">
        <Link
          to="/help"
          className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-white/40 hover:text-white hover:bg-white/5 transition-all"
          title={isCollapsed ? 'Help' : undefined}
        >
          <HelpCircle size={18} className="min-w-[18px]" />
          {!isCollapsed && <span className="text-sm">Help & Support</span>}
        </Link>
        <Link
          to="/"
          className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-white/40 hover:text-white hover:bg-white/5 transition-all"
          title={isCollapsed ? 'Notifications' : undefined}
        >
          <Bell size={18} className="min-w-[18px]" />
          {!isCollapsed && <span className="text-sm">Notifications</span>}
        </Link>
        <button
          onClick={logout}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-red-400/70 hover:text-red-400 hover:bg-red-500/10 transition-all"
          title={isCollapsed ? 'Sign Out' : undefined}
        >
          <LogOut size={18} className="min-w-[18px]" />
          {!isCollapsed && <span className="text-sm">Sign Out</span>}
        </button>
      </div>
    </motion.aside>
  );
};

export default Sidebar;
