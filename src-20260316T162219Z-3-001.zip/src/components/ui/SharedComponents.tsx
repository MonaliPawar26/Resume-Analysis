import React, { useRef, useState } from 'react';
import { motion, useMotionTemplate, useMotionValue, useSpring } from 'framer-motion';

// ============================================================
// SCORE RING COMPONENT
// ============================================================
interface ScoreRingProps {
  score: number;
  size?: number;
  label?: string;
  color?: string;
}

export const ScoreRing: React.FC<ScoreRingProps> = ({
  score,
  size = 120,
  label = 'Score',
  color = '#6366f1'
}) => {
  const radius = (size - 20) / 2;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (score / 100) * circumference;
  const scoreColor = score >= 80 ? '#10b981' : score >= 60 ? '#6366f1' : score >= 40 ? '#f59e0b' : '#ef4444';

  return (
    <div className="flex flex-col items-center">
      <div style={{ width: size, height: size }} className="relative">
        <svg width={size} height={size} className="-rotate-90">
          {/* Background circle */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke="rgba(255,255,255,0.05)"
            strokeWidth="8"
          />
          {/* Score circle */}
          <motion.circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke={color || scoreColor}
            strokeWidth="8"
            strokeLinecap="round"
            strokeDasharray={circumference}
            initial={{ strokeDashoffset: circumference }}
            animate={{ strokeDashoffset }}
            transition={{ duration: 1.5, ease: 'easeOut', delay: 0.5 }}
          />
        </svg>
        {/* Center text */}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <motion.span
            className="text-2xl font-bold text-white"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
          >
            {score}
          </motion.span>
          {label && (
            <span className="text-xs text-white/50 text-center leading-tight">{label}</span>
          )}
        </div>
      </div>
    </div>
  );
};

// ============================================================
// PROGRESS BAR
// ============================================================
interface ProgressBarProps {
  value: number;
  max?: number;
  label?: string;
  color?: string;
  showValue?: boolean;
  height?: string;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({
  value,
  max = 100,
  label,
  color,
  showValue = true,
  height = 'h-2'
}) => {
  const percentage = Math.min(100, (value / max) * 100);
  const barColor = color || (percentage >= 80 ? '#10b981' : percentage >= 60 ? '#6366f1' : percentage >= 40 ? '#f59e0b' : '#ef4444');

  return (
    <div className="w-full">
      {(label || showValue) && (
        <div className="flex items-center justify-between mb-1.5">
          {label && <span className="text-sm text-white/70">{label}</span>}
          {showValue && <span className="text-sm font-semibold text-white">{value}%</span>}
        </div>
      )}
      <div className={`progress-bar ${height}`}>
        <motion.div
          className={`progress-fill ${height}`}
          style={{ background: `linear-gradient(90deg, ${barColor}88, ${barColor})` }}
          initial={{ width: 0 }}
          animate={{ width: `${percentage}%` }}
          transition={{ duration: 1, ease: 'easeOut', delay: 0.3 }}
        />
      </div>
    </div>
  );
};

// ============================================================
// TILT CARD
// ============================================================
interface TiltCardProps {
  children: React.ReactNode;
  className?: string;
}

export const TiltCard: React.FC<TiltCardProps> = ({ children, className = '' }) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  const rotateX = useSpring(useMotionValue(0), { stiffness: 150, damping: 20 });
  const rotateY = useSpring(useMotionValue(0), { stiffness: 150, damping: 20 });

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const deltaX = e.clientX - centerX;
    const deltaY = e.clientY - centerY;

    rotateX.set((-deltaY / rect.height) * 10);
    rotateY.set((deltaX / rect.width) * 10);
    mouseX.set(e.clientX - rect.left);
    mouseY.set(e.clientY - rect.top);
  };

  const handleMouseLeave = () => {
    rotateX.set(0);
    rotateY.set(0);
  };

  const background = useMotionTemplate`radial-gradient(200px circle at ${mouseX}px ${mouseY}px, rgba(99,102,241,0.08), transparent 80%)`;

  return (
    <motion.div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={{ rotateX, rotateY, transformStyle: 'preserve-3d' }}
      className={`relative ${className}`}
    >
      <motion.div
        className="absolute inset-0 rounded-2xl pointer-events-none"
        style={{ background }}
      />
      {children}
    </motion.div>
  );
};

// ============================================================
// SKELETON LOADER
// ============================================================
interface SkeletonProps {
  className?: string;
  variant?: 'line' | 'circle' | 'rect';
  lines?: number;
}

export const Skeleton: React.FC<SkeletonProps> = ({ className = '', variant = 'rect', lines = 1 }) => {
  if (variant === 'circle') {
    return <div className={`skeleton rounded-full ${className}`} />;
  }
  if (variant === 'line') {
    return (
      <div className="space-y-2">
        {Array.from({ length: lines }).map((_, i) => (
          <div key={i} className={`skeleton h-4 rounded ${i === lines - 1 ? 'w-3/4' : 'w-full'} ${className}`} />
        ))}
      </div>
    );
  }
  return <div className={`skeleton rounded-xl ${className}`} />;
};

// ============================================================
// BADGE
// ============================================================
interface BadgeProps {
  children: React.ReactNode;
  variant?: 'success' | 'warning' | 'danger' | 'info' | 'primary' | 'default';
  className?: string;
}

export const Badge: React.FC<BadgeProps> = ({ children, variant = 'default', className = '' }) => {
  const variants = {
    success: 'badge-success',
    warning: 'badge-warning',
    danger: 'badge-danger',
    info: 'badge-info',
    primary: 'badge-primary',
    default: 'badge bg-white/10 text-white/70 border border-white/10',
  };

  return <span className={`${variants[variant]} ${className}`}>{children}</span>;
};

// ============================================================
// STAT CARD
// ============================================================
interface StatCardProps {
  label: string;
  value: string | number;
  change?: string;
  positive?: boolean;
  icon?: React.ReactNode;
  color?: string;
}

export const StatCard: React.FC<StatCardProps> = ({ label, value, change, positive = true, icon, color = 'primary' }) => {
  const colors = {
    primary: 'from-primary-500/20 to-primary-600/10 border-primary-500/20',
    cyan: 'from-cyan-500/20 to-cyan-600/10 border-cyan-500/20',
    purple: 'from-purple-500/20 to-purple-600/10 border-purple-500/20',
    emerald: 'from-emerald-500/20 to-emerald-600/10 border-emerald-500/20',
  };

  return (
    <motion.div
      className={`card-hover bg-gradient-to-br ${colors[color as keyof typeof colors] || colors.primary}`}
      whileHover={{ scale: 1.02, y: -2 }}
      transition={{ duration: 0.2 }}
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <p className="text-white/50 text-sm font-medium mb-1">{label}</p>
          <motion.p
            className="text-3xl font-bold text-white"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            {value}
          </motion.p>
        </div>
        {icon && (
          <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center text-white/70">
            {icon}
          </div>
        )}
      </div>
      {change && (
        <p className={`text-xs font-medium ${positive ? 'text-emerald-400' : 'text-red-400'}`}>
          {positive ? '↑' : '↓'} {change} from last month
        </p>
      )}
    </motion.div>
  );
};

// ============================================================
// LOADING SPINNER
// ============================================================
interface SpinnerProps {
  size?: 'sm' | 'md' | 'lg';
  label?: string;
}

export const Spinner: React.FC<SpinnerProps> = ({ size = 'md', label }) => {
  const sizes = { sm: 'w-4 h-4', md: 'w-8 h-8', lg: 'w-12 h-12' };
  return (
    <div className="flex flex-col items-center gap-3">
      <div className={`${sizes[size]} border-2 border-primary-500/20 border-t-primary-500 rounded-full animate-spin`} />
      {label && <p className="text-white/50 text-sm">{label}</p>}
    </div>
  );
};

// ============================================================
// SECTION HEADER
// ============================================================
interface SectionHeaderProps {
  badge?: string;
  title: string;
  subtitle?: string;
  centered?: boolean;
}

export const SectionHeader: React.FC<SectionHeaderProps> = ({ badge, title, subtitle, centered = true }) => {
  return (
    <motion.div
      className={`mb-16 ${centered ? 'text-center' : ''}`}
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6 }}
    >
      {badge && (
        <div className={`flex ${centered ? 'justify-center' : ''} mb-4`}>
          <span className="badge-primary text-xs px-4 py-1.5">{badge}</span>
        </div>
      )}
      <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">
        {title}
      </h2>
      {subtitle && (
        <p className={`text-white/60 text-lg ${centered ? 'max-w-2xl mx-auto' : ''}`}>
          {subtitle}
        </p>
      )}
      <div className={`mt-6 ${centered ? 'section-divider' : 'w-16 h-1 bg-gradient-to-r from-primary-500 to-accent-purple rounded-full'}`} />
    </motion.div>
  );
};
