import React, { useEffect, useRef } from 'react';
import { motion, useMotionValue, useSpring } from 'framer-motion';

const AnimatedCursor: React.FC = () => {
  const cursorX = useMotionValue(-100);
  const cursorY = useMotionValue(-100);
  const trailX = useMotionValue(-100);
  const trailY = useMotionValue(-100);
  const isHovering = useRef(false);

  const springConfig = { damping: 20, stiffness: 300, mass: 0.5 };
  const trailSpringConfig = { damping: 35, stiffness: 120, mass: 1 };

  const springX = useSpring(cursorX, springConfig);
  const springY = useSpring(cursorY, springConfig);
  const trailSpringX = useSpring(trailX, trailSpringConfig);
  const trailSpringY = useSpring(trailY, trailSpringConfig);

  const [isHovered, setIsHovered] = React.useState(false);
  const [isClicked, setIsClicked] = React.useState(false);

  useEffect(() => {
    const moveCursor = (e: MouseEvent) => {
      cursorX.set(e.clientX);
      cursorY.set(e.clientY);
      trailX.set(e.clientX);
      trailY.set(e.clientY);
    };

    const handleMouseOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (
        target.tagName === 'A' ||
        target.tagName === 'BUTTON' ||
        target.closest('a') ||
        target.closest('button') ||
        target.getAttribute('data-cursor-pointer')
      ) {
        isHovering.current = true;
        setIsHovered(true);
      } else {
        isHovering.current = false;
        setIsHovered(false);
      }
    };

    const handleMouseDown = () => setIsClicked(true);
    const handleMouseUp = () => setIsClicked(false);

    window.addEventListener('mousemove', moveCursor);
    window.addEventListener('mouseover', handleMouseOver);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);

    return () => {
      window.removeEventListener('mousemove', moveCursor);
      window.removeEventListener('mouseover', handleMouseOver);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [cursorX, cursorY, trailX, trailY]);

  return (
    <>
      {/* Cursor dot */}
      <motion.div
        className="custom-cursor"
        style={{
          left: springX,
          top: springY,
          x: '-50%',
          y: '-50%',
          width: isClicked ? '8px' : isHovered ? '0px' : '10px',
          height: isClicked ? '8px' : isHovered ? '0px' : '10px',
          backgroundColor: '#6366f1',
          zIndex: 99999,
        }}
        animate={{
          scale: isClicked ? 0.8 : 1,
        }}
        transition={{ duration: 0.1 }}
      />

      {/* Cursor ring/trail */}
      <motion.div
        className="custom-cursor"
        style={{
          left: trailSpringX,
          top: trailSpringY,
          x: '-50%',
          y: '-50%',
          zIndex: 99998,
        }}
        animate={{
          width: isHovered ? '48px' : isClicked ? '28px' : '36px',
          height: isHovered ? '48px' : isClicked ? '28px' : '36px',
          opacity: isHovered ? 0.6 : 0.3,
          backgroundColor: isHovered ? 'rgba(99,102,241,0.15)' : 'transparent',
          border: `1.5px solid ${isHovered ? 'rgba(99,102,241,0.8)' : 'rgba(99,102,241,0.5)'}`,
        }}
        transition={{ duration: 0.15 }}
      />
    </>
  );
};

export default AnimatedCursor;
