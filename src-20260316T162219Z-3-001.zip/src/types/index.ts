// ============================================================
// AI Resume Analyzer & Job Match Platform - Type Definitions
// ============================================================

export type UserRole = 'candidate' | 'recruiter' | 'admin';
export type PlanType = 'free' | 'pro' | 'recruiter';
export type ThemeMode = 'dark' | 'light';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  plan: PlanType;
  avatar?: string;
  createdAt: string;
  scansUsed: number;
  scansLimit: number;
}

export interface ResumeAnalysis {
  id: string;
  userId: string;
  fileName: string;
  uploadedAt: string;
  overallScore: number;
  skillMatchPercent: number;
  keywordDensityPercent: number;
  atsScore: number;
  skills: ExtractedSkill[];
  experience: ExperienceItem[];
  education: EducationItem[];
  projects: ProjectItem[];
  certifications: string[];
  missingKeywords: string[];
  atsIssues: ATSIssue[];
  suggestions: Suggestion[];
  sectionScores: SectionScore[];
  aiRewrite?: string;
}

export interface ExtractedSkill {
  name: string;
  category: 'technical' | 'soft' | 'tool' | 'language';
  level: 'beginner' | 'intermediate' | 'advanced' | 'expert';
  yearsOfExp?: number;
}

export interface ExperienceItem {
  company: string;
  title: string;
  duration: string;
  description: string;
  skills: string[];
}

export interface EducationItem {
  institution: string;
  degree: string;
  field: string;
  year: string;
  gpa?: string;
}

export interface ProjectItem {
  name: string;
  description: string;
  technologies: string[];
  link?: string;
}

export interface ATSIssue {
  type: 'critical' | 'warning' | 'info';
  message: string;
  suggestion: string;
}

export interface Suggestion {
  section: string;
  priority: 'high' | 'medium' | 'low';
  issue: string;
  recommendation: string;
}

export interface SectionScore {
  section: string;
  score: number;
  maxScore: number;
  status: 'excellent' | 'good' | 'needs_improvement' | 'missing';
}

export interface JobDescription {
  id: string;
  title: string;
  company: string;
  description: string;
  requiredSkills: string[];
  preferredSkills: string[];
  experienceLevel: string;
  location: string;
  salary?: string;
  postedAt: string;
  postedBy?: string;
}

export interface JobMatch {
  jobId: string;
  job: JobDescription;
  overallScore: number;
  skillMatchPercent: number;
  experienceMatchPercent: number;
  missingSkills: string[];
  matchedSkills: string[];
  suggestions: string[];
}

export interface Candidate {
  id: string;
  user: User;
  latestResume?: ResumeAnalysis;
  applications: string[];
  status: 'active' | 'inactive' | 'hired';
}

export interface SubscriptionPlan {
  id: PlanType;
  name: string;
  price: number;
  period: 'month' | 'year';
  features: string[];
  scansLimit: number;
  highlighted?: boolean;
}

export interface AdminStats {
  totalUsers: number;
  activeUsers: number;
  totalScans: number;
  totalJobs: number;
  revenue: number;
  conversionRate: number;
}

export interface ChartData {
  name: string;
  value: number;
  color?: string;
}

export interface AnalyticData {
  date: string;
  scans: number;
  signups: number;
  revenue: number;
}
