import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  User, Shield, Bell, Palette, CreditCard, Key,
  Save, Camera, Mail, Phone, MapPin, Globe, Award,
  CheckCircle, Trash2, Download, Eye, EyeOff
} from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import Sidebar from '../../components/layout/Sidebar';

const ProfilePage: React.FC = () => {
  const { user, logout } = useAuthStore();
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [activeTab, setActiveTab] = useState<'profile' | 'security' | 'notifications' | 'billing' | 'privacy'>('profile');
  const [showPassword, setShowPassword] = useState(false);
  const [saved, setSaved] = useState(false);
  const [formData, setFormData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: '+1 (555) 012-3456',
    location: 'San Francisco, CA',
    website: 'https://alexjohnson.dev',
    bio: 'Full-stack developer with 3 years of experience building scalable web applications. Passionate about React, TypeScript, and cloud architecture.',
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });

  const [notifications, setNotifications] = useState({
    emailJobMatches: true,
    emailResumeAnalysis: true,
    emailWeeklyDigest: false,
    emailMarketing: false,
    pushNotifications: true,
    pushJobAlerts: true,
  });

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const tabs = [
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'security', label: 'Security', icon: Shield },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'billing', label: 'Billing', icon: CreditCard },
    { id: 'privacy', label: 'Privacy', icon: Key },
  ];

  const planColors: Record<string, string> = {
    free: 'from-gray-500 to-gray-600',
    pro: 'from-primary-500 to-accent-purple',
    recruiter: 'from-accent-cyan to-primary-500',
  };

  return (
    <div className="flex min-h-screen bg-dark-bg">
      <Sidebar isCollapsed={sidebarCollapsed} onToggle={() => setSidebarCollapsed(!sidebarCollapsed)} />

      <main className={`flex-1 transition-all duration-300 ${sidebarCollapsed ? 'ml-16' : 'ml-64'}`}>
        {/* Header */}
        <div className="sticky top-0 z-30 bg-dark-bg/80 backdrop-blur-xl border-b border-dark-border px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-white">Account Settings</h1>
              <p className="text-white/40 text-sm">Manage your profile and preferences</p>
            </div>
            <motion.button
              onClick={handleSave}
              className={`btn-primary flex items-center gap-2 ${saved ? 'bg-emerald-600 hover:bg-emerald-500' : ''}`}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.97 }}
            >
              {saved ? <CheckCircle size={16} /> : <Save size={16} />}
              {saved ? 'Saved!' : 'Save Changes'}
            </motion.button>
          </div>
        </div>

        <div className="p-6 max-w-5xl mx-auto">
          <div className="flex gap-6">
            {/* Tab navigation */}
            <div className="w-52 shrink-0">
              <nav className="space-y-1">
                {tabs.map(tab => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id as typeof activeTab)}
                      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                        activeTab === tab.id
                          ? 'bg-primary-600/20 text-primary-400 border border-primary-500/30'
                          : 'text-white/50 hover:text-white hover:bg-white/5'
                      }`}
                    >
                      <Icon size={16} />
                      {tab.label}
                    </button>
                  );
                })}
              </nav>

              {/* Plan Badge */}
              <div className="mt-6 p-4 glass rounded-xl border border-dark-border">
                <div className="text-xs text-white/40 mb-2">Current Plan</div>
                <div className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold text-white bg-gradient-to-r ${planColors[user?.plan || 'free']}`}>
                  <Award size={12} />
                  {user?.plan?.toUpperCase() || 'FREE'}
                </div>
                <button className="mt-3 w-full text-xs text-primary-400 hover:text-primary-300 font-medium transition-colors">
                  Upgrade Plan →
                </button>
              </div>
            </div>

            {/* Content */}
            <div className="flex-1">
              {activeTab === 'profile' && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="space-y-6"
                >
                  {/* Avatar section */}
                  <div className="glass-card rounded-2xl p-6">
                    <h3 className="text-white font-semibold mb-4">Profile Picture</h3>
                    <div className="flex items-center gap-6">
                      <div className="relative">
                        <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-primary-500 to-accent-purple flex items-center justify-center text-2xl font-bold text-white shadow-glow">
                          {formData.name.charAt(0).toUpperCase()}
                        </div>
                        <button className="absolute -bottom-2 -right-2 w-7 h-7 rounded-full bg-primary-600 flex items-center justify-center hover:bg-primary-500 transition-colors">
                          <Camera size={13} className="text-white" />
                        </button>
                      </div>
                      <div>
                        <p className="text-white font-medium">{formData.name}</p>
                        <p className="text-white/40 text-sm capitalize">{user?.role} • {user?.plan?.toUpperCase()} Plan</p>
                        <button className="mt-2 text-xs text-primary-400 hover:text-primary-300 transition-colors">
                          Upload new photo
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Personal info */}
                  <div className="glass-card rounded-2xl p-6">
                    <h3 className="text-white font-semibold mb-5">Personal Information</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {[
                        { label: 'Full Name', key: 'name', icon: User, type: 'text' },
                        { label: 'Email Address', key: 'email', icon: Mail, type: 'email' },
                        { label: 'Phone', key: 'phone', icon: Phone, type: 'tel' },
                        { label: 'Location', key: 'location', icon: MapPin, type: 'text' },
                        { label: 'Website', key: 'website', icon: Globe, type: 'url' },
                      ].map(field => {
                        const Icon = field.icon;
                        return (
                          <div key={field.key} className={field.key === 'website' ? 'md:col-span-2' : ''}>
                            <label className="block text-white/60 text-sm mb-2">{field.label}</label>
                            <div className="relative">
                              <Icon size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30" />
                              <input
                                type={field.type}
                                value={(formData as Record<string, string>)[field.key]}
                                onChange={e => setFormData(prev => ({ ...prev, [field.key]: e.target.value }))}
                                className="w-full bg-dark-surface border border-dark-border text-white placeholder-white/20 rounded-xl pl-9 pr-4 py-2.5 text-sm focus:outline-none focus:border-primary-500/60 transition-colors"
                              />
                            </div>
                          </div>
                        );
                      })}

                      <div className="md:col-span-2">
                        <label className="block text-white/60 text-sm mb-2">Bio</label>
                        <textarea
                          value={formData.bio}
                          onChange={e => setFormData(prev => ({ ...prev, bio: e.target.value }))}
                          rows={3}
                          className="w-full bg-dark-surface border border-dark-border text-white placeholder-white/20 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-primary-500/60 transition-colors resize-none"
                        />
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === 'security' && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="space-y-6"
                >
                  <div className="glass-card rounded-2xl p-6">
                    <h3 className="text-white font-semibold mb-5">Change Password</h3>
                    <div className="space-y-4">
                      {[
                        { label: 'Current Password', key: 'currentPassword' },
                        { label: 'New Password', key: 'newPassword' },
                        { label: 'Confirm New Password', key: 'confirmPassword' },
                      ].map(field => (
                        <div key={field.key}>
                          <label className="block text-white/60 text-sm mb-2">{field.label}</label>
                          <div className="relative">
                            <Key size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30" />
                            <input
                              type={showPassword ? 'text' : 'password'}
                              value={(formData as Record<string, string>)[field.key]}
                              onChange={e => setFormData(prev => ({ ...prev, [field.key]: e.target.value }))}
                              placeholder="••••••••"
                              className="w-full bg-dark-surface border border-dark-border text-white placeholder-white/20 rounded-xl pl-9 pr-10 py-2.5 text-sm focus:outline-none focus:border-primary-500/60 transition-colors"
                            />
                            <button
                              type="button"
                              onClick={() => setShowPassword(!showPassword)}
                              className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60"
                            >
                              {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="mt-4 p-4 rounded-xl bg-primary-600/10 border border-primary-500/20">
                      <p className="text-xs text-white/50">Password requirements:</p>
                      <ul className="mt-2 space-y-1 text-xs text-white/40">
                        {['At least 8 characters', 'One uppercase letter', 'One number', 'One special character'].map(req => (
                          <li key={req} className="flex items-center gap-2">
                            <div className="w-1 h-1 rounded-full bg-white/30" />
                            {req}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="glass-card rounded-2xl p-6">
                    <h3 className="text-white font-semibold mb-1">Two-Factor Authentication</h3>
                    <p className="text-white/40 text-sm mb-4">Add an extra layer of security to your account</p>
                    <button className="btn-primary flex items-center gap-2 text-sm">
                      <Shield size={16} />
                      Enable 2FA
                    </button>
                  </div>

                  <div className="glass-card rounded-2xl p-6 border-red-500/20">
                    <h3 className="text-red-400 font-semibold mb-1">Danger Zone</h3>
                    <p className="text-white/40 text-sm mb-4">Permanently delete your account and all associated data</p>
                    <button className="flex items-center gap-2 px-4 py-2 rounded-xl border border-red-500/30 text-red-400 text-sm font-medium hover:bg-red-500/10 transition-all">
                      <Trash2 size={15} />
                      Delete Account
                    </button>
                  </div>
                </motion.div>
              )}

              {activeTab === 'notifications' && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="space-y-6"
                >
                  <div className="glass-card rounded-2xl p-6">
                    <h3 className="text-white font-semibold mb-5">Email Notifications</h3>
                    <div className="space-y-4">
                      {[
                        { key: 'emailJobMatches', label: 'Job Match Alerts', desc: 'Get notified when new jobs match your profile' },
                        { key: 'emailResumeAnalysis', label: 'Resume Analysis Complete', desc: 'Receive results when AI finishes analyzing' },
                        { key: 'emailWeeklyDigest', label: 'Weekly Digest', desc: 'Summary of your job search progress every week' },
                        { key: 'emailMarketing', label: 'Tips & Updates', desc: 'Product updates and career tips from our team' },
                      ].map(item => (
                        <div key={item.key} className="flex items-center justify-between py-3 border-b border-dark-border last:border-0">
                          <div>
                            <p className="text-white text-sm font-medium">{item.label}</p>
                            <p className="text-white/40 text-xs mt-0.5">{item.desc}</p>
                          </div>
                          <button
                            onClick={() => setNotifications(prev => ({ ...prev, [item.key]: !prev[item.key as keyof typeof prev] }))}
                            className={`relative w-11 h-6 rounded-full transition-colors ${
                              notifications[item.key as keyof typeof notifications] ? 'bg-primary-600' : 'bg-dark-border'
                            }`}
                          >
                            <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-sm transition-all ${
                              notifications[item.key as keyof typeof notifications] ? 'left-[22px]' : 'left-0.5'
                            }`} />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === 'billing' && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="space-y-6"
                >
                  <div className="glass-card rounded-2xl p-6">
                    <div className="flex items-center justify-between mb-6">
                      <div>
                        <h3 className="text-white font-semibold">Current Plan</h3>
                        <p className="text-white/40 text-sm">Manage your subscription</p>
                      </div>
                      <div className={`px-4 py-2 rounded-xl text-sm font-bold text-white bg-gradient-to-r ${planColors[user?.plan || 'free']}`}>
                        {user?.plan?.toUpperCase() || 'FREE'}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      {[
                        { plan: 'Free', price: '$0', features: ['3 resume scans/month', 'Basic job matching', 'ATS score'], active: user?.plan === 'free' },
                        { plan: 'Pro', price: '$19/mo', features: ['Unlimited scans', 'Advanced AI feedback', 'Resume rewriting', 'Priority support'], active: user?.plan === 'pro', highlight: true },
                        { plan: 'Recruiter', price: '$49/mo', features: ['Bulk resume ranking', 'AI filtering', 'Team dashboard', 'Export candidates'], active: user?.plan === 'recruiter' },
                      ].map(p => (
                        <div key={p.plan} className={`p-4 rounded-xl border ${p.active ? 'border-primary-500/50 bg-primary-600/10' : 'border-dark-border'} ${p.highlight && !p.active ? 'border-accent-purple/30' : ''}`}>
                          <div className="font-bold text-white mb-1">{p.plan}</div>
                          <div className={`text-xl font-black mb-3 ${p.highlight ? 'gradient-text' : 'text-white'}`}>{p.price}</div>
                          <ul className="space-y-1.5">
                            {p.features.map(f => (
                              <li key={f} className="flex items-center gap-2 text-xs text-white/50">
                                <CheckCircle size={12} className="text-emerald-400" />
                                {f}
                              </li>
                            ))}
                          </ul>
                          {!p.active && (
                            <button className={`mt-4 w-full py-2 rounded-lg text-xs font-semibold text-white transition-all ${p.highlight ? 'bg-gradient-to-r from-primary-600 to-accent-purple hover:opacity-90' : 'bg-white/10 hover:bg-white/20'}`}>
                              Upgrade
                            </button>
                          )}
                          {p.active && (
                            <div className="mt-4 text-xs text-primary-400 font-medium">✓ Current plan</div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="glass-card rounded-2xl p-6">
                    <h3 className="text-white font-semibold mb-4">Billing History</h3>
                    <div className="space-y-3">
                      {[
                        { date: 'Feb 01, 2026', amount: '$19.00', status: 'Paid', plan: 'Pro Monthly' },
                        { date: 'Jan 01, 2026', amount: '$19.00', status: 'Paid', plan: 'Pro Monthly' },
                        { date: 'Dec 01, 2025', amount: '$19.00', status: 'Paid', plan: 'Pro Monthly' },
                      ].map((invoice, i) => (
                        <div key={i} className="flex items-center justify-between py-3 border-b border-dark-border last:border-0">
                          <div>
                            <p className="text-white text-sm font-medium">{invoice.plan}</p>
                            <p className="text-white/40 text-xs">{invoice.date}</p>
                          </div>
                          <div className="flex items-center gap-3">
                            <span className="text-emerald-400 text-sm font-semibold">{invoice.amount}</span>
                            <button className="text-white/30 hover:text-white/60 transition-colors">
                              <Download size={14} />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === 'privacy' && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="space-y-6"
                >
                  <div className="glass-card rounded-2xl p-6">
                    <h3 className="text-white font-semibold mb-5">Privacy Settings</h3>
                    <div className="space-y-4">
                      {[
                        { label: 'Profile Visibility', desc: 'Make your profile visible to recruiters', default: true },
                        { label: 'Resume Sharing', desc: 'Allow recruiters to view your resume', default: true },
                        { label: 'Analytics Tracking', desc: 'Help us improve with anonymized usage data', default: true },
                        { label: 'Resume Auto-Delete', desc: 'Automatically delete resumes after 90 days', default: false },
                      ].map((item, i) => {
                        const [enabled, setEnabled] = React.useState(item.default);
                        return (
                          <div key={i} className="flex items-center justify-between py-3 border-b border-dark-border last:border-0">
                            <div>
                              <p className="text-white text-sm font-medium">{item.label}</p>
                              <p className="text-white/40 text-xs mt-0.5">{item.desc}</p>
                            </div>
                            <button
                              onClick={() => setEnabled(!enabled)}
                              className={`relative w-11 h-6 rounded-full transition-colors ${enabled ? 'bg-primary-600' : 'bg-dark-border'}`}
                            >
                              <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-sm transition-all ${enabled ? 'left-[22px]' : 'left-0.5'}`} />
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  <div className="glass-card rounded-2xl p-6">
                    <h3 className="text-white font-semibold mb-2">Data Export</h3>
                    <p className="text-white/40 text-sm mb-4">Download all your data including resumes, analyses, and account information.</p>
                    <button className="flex items-center gap-2 px-4 py-2 rounded-xl glass border border-white/10 text-white/70 text-sm font-medium hover:bg-white/10 transition-all">
                      <Download size={15} />
                      Export My Data
                    </button>
                  </div>
                </motion.div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default ProfilePage;
