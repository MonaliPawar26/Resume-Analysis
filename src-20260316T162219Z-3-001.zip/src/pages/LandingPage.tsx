import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  BrainCircuit, ArrowRight, Star, Zap, Shield, Users,
  Upload, FileText, Search, BarChart3, CheckCircle,
  Play, ChevronRight, Globe, Award, TrendingUp, Sparkles
} from 'lucide-react';
import { ParticleBackground, FloatingOrbs, GridBackground } from '../components/animations/Backgrounds';
import Navbar from '../components/layout/Navbar';
import Footer from '../components/layout/Footer';
import { TiltCard, SectionHeader } from '../components/ui/SharedComponents';
import { useAuthStore } from '../store/authStore';

// ============================================================
// HERO SECTION
// ============================================================
const HeroSection: React.FC = () => {
  const navigate = useNavigate();
  const { isAuthenticated, user } = useAuthStore();
  const [isVideoOpen, setIsVideoOpen] = useState(false);

  const handleGetStarted = () => {
    if (isAuthenticated) {
      navigate(user?.role === 'recruiter' ? '/recruiter' : '/dashboard');
    } else {
      navigate('/register');
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden">
      <ParticleBackground />
      <GridBackground />
      <FloatingOrbs />

      {/* Hero gradient */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-64 bg-primary-600/20 rounded-full blur-3xl" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Announcement Badge */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-primary-500/30 mb-8"
        >
          <Sparkles size={14} className="text-primary-400" />
          <span className="text-sm text-white/80">
            <span className="text-primary-400 font-semibold">New:</span> AI Resume Rewrite powered by GPT-4
          </span>
          <ChevronRight size={14} className="text-white/50" />
        </motion.div>

        {/* Headline */}
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="text-5xl sm:text-6xl lg:text-7xl xl:text-8xl font-bold text-white mb-6 leading-[0.95] tracking-tight"
        >
          Land Your{' '}
          <span className="gradient-text">Dream Job</span>
          <br />
          with AI Power
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="text-lg md:text-xl text-white/60 max-w-2xl mx-auto mb-10 leading-relaxed"
        >
          AI-powered resume analysis, intelligent job matching, and instant ATS optimization. 
          Join 50,000+ professionals who landed jobs 3x faster.
        </motion.p>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16"
        >
          <motion.button
            onClick={handleGetStarted}
            className="btn-primary text-base px-8 py-4 flex items-center gap-3 group"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.97 }}
          >
            <Zap size={18} />
            Analyze My Resume Free
            <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
          </motion.button>
          <motion.button
            onClick={() => setIsVideoOpen(true)}
            className="flex items-center gap-3 px-8 py-4 rounded-xl glass border border-white/15 text-white font-semibold hover:bg-white/10 transition-all"
            whileHover={{ scale: 1.05 }}
          >
            <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center">
              <Play size={14} className="text-white ml-0.5" />
            </div>
            Watch Demo
          </motion.button>
        </motion.div>

        {/* Social Proof */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-8 text-sm text-white/50"
        >
          <div className="flex -space-x-2">
            {['A', 'B', 'C', 'D', 'E'].map((letter, i) => (
              <div
                key={i}
                className="w-8 h-8 rounded-full border-2 border-dark-bg flex items-center justify-center text-xs font-bold text-white"
                style={{
                  background: `hsl(${i * 60 + 200}, 70%, 60%)`,
                }}
              >
                {letter}
              </div>
            ))}
          </div>
          <span>Join <strong className="text-white">50,000+</strong> users worldwide</span>
          <div className="flex items-center gap-1">
            {Array.from({length: 5}).map((_, i) => (
              <Star key={i} size={14} className="text-yellow-400 fill-yellow-400" />
            ))}
            <span className="ml-1"><strong className="text-white">4.9/5</strong> rating</span>
          </div>
        </motion.div>

        {/* Hero Stats */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7, duration: 0.7 }}
          className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-4"
        >
          {[
            { value: '50K+', label: 'Resumes Analyzed' },
            { value: '95%', label: 'ATS Pass Rate' },
            { value: '3x', label: 'Faster Job Search' },
            { value: '10K+', label: 'Jobs Matched' },
          ].map((stat, i) => (
            <motion.div
              key={i}
              className="glass-card rounded-2xl p-5 text-center"
              whileHover={{ y: -4, borderColor: 'rgba(99,102,241,0.3)' }}
              transition={{ duration: 0.2 }}
            >
              <div className="text-3xl font-bold gradient-text mb-1">{stat.value}</div>
              <div className="text-white/50 text-sm">{stat.label}</div>
            </motion.div>
          ))}
        </motion.div>
      </div>

      {/* Video Modal */}
      <AnimatePresence>
        {isVideoOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm"
            onClick={() => setIsVideoOpen(false)}
          >
            <motion.div
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              className="w-full max-w-3xl aspect-video glass-card rounded-2xl flex items-center justify-center"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="text-center">
                <div className="w-20 h-20 rounded-full bg-primary-600/30 border border-primary-500/50 flex items-center justify-center mx-auto mb-4">
                  <Play size={32} className="text-white ml-1" />
                </div>
                <p className="text-white/50">Demo video would play here</p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
};

// ============================================================
// FEATURES SECTION
// ============================================================
const FeaturesSection: React.FC = () => {
  const features = [
    {
      icon: FileText,
      title: 'AI Resume Analysis',
      description: 'Deep NLP analysis extracts skills, experience, education, and provides a comprehensive score.',
      color: 'from-primary-500 to-primary-700',
      stats: '98% accuracy',
    },
    {
      icon: Search,
      title: 'Intelligent Job Matching',
      description: 'Semantic similarity matching finds your best-fit jobs ranked by compatibility score.',
      color: 'from-accent-purple to-primary-600',
      stats: '3x more interviews',
    },
    {
      icon: Shield,
      title: 'ATS Optimization',
      description: 'Identify and fix ATS parsing issues to ensure your resume passes automated screening.',
      color: 'from-accent-cyan to-primary-500',
      stats: '95% pass rate',
    },
    {
      icon: Zap,
      title: 'AI Resume Rewrite',
      description: 'Get AI-powered rewrites and suggestions that transform a weak resume into a standout one.',
      color: 'from-accent-pink to-accent-purple',
      stats: 'Instant results',
    },
    {
      icon: BarChart3,
      title: 'Skill Gap Analysis',
      description: 'Visualize exactly which skills you\'re missing for your target roles with actionable guidance.',
      color: 'from-primary-500 to-accent-cyan',
      stats: 'Targeted learning',
    },
    {
      icon: Users,
      title: 'Recruiter Tools',
      description: 'AI-powered bulk resume ranking and candidate shortlisting for HR teams and recruiters.',
      color: 'from-accent-emerald to-accent-cyan',
      stats: '10x faster hiring',
    },
  ];

  return (
    <section id="features" className="py-24 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeader
          badge="✨ Powerful Features"
          title="Everything You Need to Land Your Dream Job"
          subtitle="From AI-powered analysis to intelligent job matching — our platform gives you the unfair advantage in today's competitive job market."
        />

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, i) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
              >
                <TiltCard className="card-hover h-full group">
                  <div className="flex items-start gap-4 mb-4">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center shadow-glow flex-shrink-0`}>
                      <Icon size={22} className="text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-white font-semibold text-lg mb-1">{feature.title}</h3>
                      <span className="text-xs text-primary-400 font-medium">{feature.stats}</span>
                    </div>
                  </div>
                  <p className="text-white/60 text-sm leading-relaxed">{feature.description}</p>
                  <div className="mt-4 flex items-center gap-2 text-primary-400 text-sm font-medium group-hover:gap-3 transition-all">
                    Learn more <ChevronRight size={14} />
                  </div>
                </TiltCard>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

// ============================================================
// HOW IT WORKS
// ============================================================
const HowItWorks: React.FC = () => {
  const steps = [
    {
      step: '01',
      icon: Upload,
      title: 'Upload Your Resume',
      description: 'Simply drag & drop your PDF or DOCX resume. We support all standard formats.',
    },
    {
      step: '02',
      icon: BrainCircuit,
      title: 'AI Deep Analysis',
      description: 'Our NLP engine analyzes skills, experience, formatting, and ATS compatibility in seconds.',
    },
    {
      step: '03',
      icon: Search,
      title: 'Get Job Matches',
      description: 'Receive ranked job recommendations with match percentages and missing skills.',
    },
    {
      step: '04',
      icon: TrendingUp,
      title: 'Optimize & Apply',
      description: 'Use AI suggestions to improve your resume, then apply with confidence.',
    },
  ];

  return (
    <section id="how-it-works" className="py-24 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary-950/20 to-transparent" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <SectionHeader
          badge="🚀 Simple Process"
          title="From Upload to Job Offer in Minutes"
          subtitle="Our streamlined 4-step process takes the guesswork out of your job search."
        />

        <div className="grid md:grid-cols-4 gap-6 relative">
          {/* Connection line */}
          <div className="hidden md:block absolute top-1/4 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary-500/30 to-transparent" />

          {steps.map((step, i) => {
            const Icon = step.icon;
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15, duration: 0.5 }}
                className="text-center relative"
              >
                <div className="relative inline-block mb-6">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary-600 to-accent-purple flex items-center justify-center shadow-glow mx-auto">
                    <Icon size={28} className="text-white" />
                  </div>
                  <div className="absolute -top-2 -right-2 w-7 h-7 rounded-full bg-dark-card border border-primary-500/50 flex items-center justify-center text-xs font-bold text-primary-400">
                    {step.step}
                  </div>
                </div>
                <h3 className="text-white font-semibold text-lg mb-3">{step.title}</h3>
                <p className="text-white/60 text-sm leading-relaxed">{step.description}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

// ============================================================
// PRICING SECTION
// ============================================================
const PricingSection: React.FC = () => {
  const [billing, setBilling] = useState<'monthly' | 'yearly'>('monthly');
  const navigate = useNavigate();

  const plans = [
    {
      id: 'free',
      name: 'Free',
      price: { monthly: 0, yearly: 0 },
      description: 'Perfect for getting started',
      features: [
        '3 Resume scans / month',
        'Basic ATS check',
        'Job matching (5/month)',
        'Resume score',
        'Basic suggestions',
      ],
      excluded: ['AI rewrite', 'Detailed analytics', 'Unlimited scans'],
      cta: 'Start Free',
      highlighted: false,
      color: 'border-white/10',
    },
    {
      id: 'pro',
      name: 'Pro',
      price: { monthly: 19, yearly: 12 },
      description: 'For serious job seekers',
      features: [
        'Unlimited resume scans',
        'Advanced ATS analyzer',
        'Unlimited job matching',
        'AI resume rewrite',
        'Detailed skill gap analysis',
        'Resume history tracking',
        'Priority support',
        'Export reports',
      ],
      excluded: [],
      cta: 'Start Pro Trial',
      highlighted: true,
      color: 'border-primary-500/50',
    },
    {
      id: 'recruiter',
      name: 'Recruiter',
      price: { monthly: 79, yearly: 59 },
      description: 'For HR teams & recruiters',
      features: [
        'Everything in Pro',
        'Post unlimited jobs',
        'Bulk resume ranking (AI)',
        'Candidate shortlisting',
        'Team collaboration',
        'Export candidate list',
        'API access',
        'Dedicated support',
      ],
      excluded: [],
      cta: 'Start Recruiter Trial',
      highlighted: false,
      color: 'border-accent-purple/40',
    },
  ];

  return (
    <section id="pricing" className="py-24 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeader
          badge="💎 Pricing"
          title="Simple, Transparent Pricing"
          subtitle="No hidden fees. Cancel anytime. Start free."
        />

        {/* Billing Toggle */}
        <div className="flex items-center justify-center gap-4 mb-12">
          <button
            onClick={() => setBilling('monthly')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${billing === 'monthly' ? 'bg-primary-600 text-white' : 'text-white/50 hover:text-white'}`}
          >
            Monthly
          </button>
          <div
            className="w-12 h-6 rounded-full bg-primary-600/30 border border-primary-500/50 flex items-center px-1 cursor-pointer"
            onClick={() => setBilling(b => b === 'monthly' ? 'yearly' : 'monthly')}
          >
            <motion.div
              className="w-4 h-4 rounded-full bg-primary-400"
              animate={{ x: billing === 'yearly' ? 24 : 0 }}
              transition={{ duration: 0.2 }}
            />
          </div>
          <button
            onClick={() => setBilling('yearly')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${billing === 'yearly' ? 'bg-primary-600 text-white' : 'text-white/50 hover:text-white'}`}
          >
            Yearly <span className="text-emerald-400 text-xs ml-1">-35%</span>
          </button>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {plans.map((plan, i) => (
            <motion.div
              key={plan.id}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className={`relative rounded-2xl border ${plan.color} p-8 ${plan.highlighted ? 'bg-gradient-to-b from-primary-600/15 to-primary-900/10 shadow-glow-lg' : 'glass-card'}`}
            >
              {plan.highlighted && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <span className="px-4 py-1.5 rounded-full bg-gradient-to-r from-primary-500 to-accent-purple text-white text-xs font-bold shadow-glow">
                    ✨ Most Popular
                  </span>
                </div>
              )}

              <div className="mb-6">
                <h3 className="text-white font-bold text-xl mb-1">{plan.name}</h3>
                <p className="text-white/50 text-sm">{plan.description}</p>
              </div>

              <div className="mb-8">
                <div className="flex items-end gap-1">
                  <span className="text-5xl font-bold text-white">${plan.price[billing]}</span>
                  {plan.price[billing] > 0 && (
                    <span className="text-white/50 text-sm mb-2">/mo</span>
                  )}
                </div>
                {billing === 'yearly' && plan.price.yearly > 0 && (
                  <p className="text-emerald-400 text-xs mt-1">Billed ${plan.price.yearly * 12}/year</p>
                )}
              </div>

              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, j) => (
                  <li key={j} className="flex items-start gap-2.5 text-sm">
                    <CheckCircle size={16} className="text-emerald-400 mt-0.5 flex-shrink-0" />
                    <span className="text-white/80">{feature}</span>
                  </li>
                ))}
                {plan.excluded.map((feature, j) => (
                  <li key={`ex-${j}`} className="flex items-start gap-2.5 text-sm">
                    <div className="w-4 h-4 rounded-full border border-white/20 mt-0.5 flex-shrink-0" />
                    <span className="text-white/30 line-through">{feature}</span>
                  </li>
                ))}
              </ul>

              <motion.button
                onClick={() => navigate('/register')}
                className={`w-full py-3 rounded-xl font-semibold text-sm transition-all ${
                  plan.highlighted
                    ? 'btn-primary'
                    : 'glass border border-white/20 text-white hover:bg-white/10'
                }`}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                {plan.cta}
              </motion.button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

// ============================================================
// TESTIMONIALS
// ============================================================
const TestimonialsSection: React.FC = () => {
  const testimonials = [
    {
      name: 'Priya Sharma',
      role: 'Software Engineer @ Google',
      avatar: 'P',
      color: '#4f46e5',
      content: 'ResumeAI helped me increase my resume score from 62 to 91. Got interviews at 4 FAANG companies within 2 weeks!',
      stars: 5,
    },
    {
      name: 'Marcus Johnson',
      role: 'Product Manager @ Stripe',
      avatar: 'M',
      color: '#7c3aed',
      content: 'The job matching feature is incredible. It found roles I hadn\'t considered and I matched 87% with my dream PM role.',
      stars: 5,
    },
    {
      name: 'Sarah Chen',
      role: 'Data Scientist @ Netflix',
      avatar: 'S',
      color: '#0891b2',
      content: 'As a career switcher from finance, the skill gap analysis showed me exactly what to learn. Landed a DS role in 3 months!',
      stars: 5,
    },
    {
      name: 'Rahul Patel',
      role: 'HR Manager @ Infosys',
      avatar: 'R',
      color: '#059669',
      content: 'The recruiter dashboard saved our team 15+ hours per week. AI ranking is incredibly accurate for candidate screening.',
      stars: 5,
    },
    {
      name: 'Emma Williams',
      role: 'UX Designer @ Meta',
      avatar: 'E',
      color: '#dc2626',
      content: 'The ATS checker revealed 8 issues in my resume I had no idea about. Fixed them and my response rate tripled!',
      stars: 5,
    },
    {
      name: 'James Kim',
      role: 'DevOps Engineer @ AWS',
      avatar: 'J',
      color: '#d97706',
      content: 'AI rewrite feature transformed my generic resume into a tailored one. Best investment for my job search.',
      stars: 5,
    },
  ];

  return (
    <section id="testimonials" className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-accent-purple/5 to-transparent" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <SectionHeader
          badge="💬 Testimonials"
          title="Loved by 50,000+ Job Seekers"
          subtitle="Don't take our word for it. Here's what our users say."
        />

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
            >
              <TiltCard className="card-hover h-full">
                <div className="flex items-center gap-3 mb-4">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold text-sm"
                    style={{ background: t.color }}
                  >
                    {t.avatar}
                  </div>
                  <div>
                    <p className="text-white font-semibold text-sm">{t.name}</p>
                    <p className="text-white/50 text-xs">{t.role}</p>
                  </div>
                </div>
                <div className="flex gap-0.5 mb-3">
                  {Array.from({length: t.stars}).map((_, j) => (
                    <Star key={j} size={13} className="text-yellow-400 fill-yellow-400" />
                  ))}
                </div>
                <p className="text-white/70 text-sm leading-relaxed">"{t.content}"</p>
              </TiltCard>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

// ============================================================
// COMPANIES SECTION
// ============================================================
const CompaniesSection: React.FC = () => {
  const companies = ['Google', 'Meta', 'Amazon', 'Apple', 'Microsoft', 'Netflix', 'Stripe', 'Airbnb'];
  return (
    <section className="py-16 border-y border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <p className="text-center text-white/30 text-sm mb-10 font-medium uppercase tracking-wider">
          Our users got hired at
        </p>
        <div className="flex flex-wrap items-center justify-center gap-8 md:gap-12">
          {companies.map((company, i) => (
            <motion.span
              key={i}
              className="text-white/20 hover:text-white/50 font-bold text-lg transition-colors cursor-default"
              whileHover={{ scale: 1.1 }}
            >
              {company}
            </motion.span>
          ))}
        </div>
      </div>
    </section>
  );
};

// ============================================================
// CTA SECTION
// ============================================================
const CTASection: React.FC = () => {
  const navigate = useNavigate();
  return (
    <section className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-primary-900/30 via-primary-800/20 to-accent-purple/20" />
      <div className="absolute inset-0" style={{
        backgroundImage: 'radial-gradient(circle at 50% 50%, rgba(99,102,241,0.15) 0%, transparent 70%)',
      }} />
      <div className="max-w-4xl mx-auto px-4 text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border border-primary-500/30 mb-6">
            <Award size={14} className="text-primary-400" />
            <span className="text-sm text-white/80">Free forever — no credit card required</span>
          </div>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6">
            Ready to Land Your<br />
            <span className="gradient-text">Dream Job?</span>
          </h2>
          <p className="text-white/60 text-lg mb-10">
            Join 50,000+ professionals who transformed their job search with AI.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <motion.button
              onClick={() => navigate('/register')}
              className="btn-primary text-base px-8 py-4 flex items-center gap-2"
              whileHover={{ scale: 1.05 }}
            >
              <Zap size={18} />
              Start for Free
              <ArrowRight size={18} />
            </motion.button>
            <motion.button
              onClick={() => navigate('/register?role=recruiter')}
              className="px-8 py-4 glass rounded-xl border border-white/20 text-white font-semibold hover:bg-white/10 transition-all flex items-center gap-2"
              whileHover={{ scale: 1.05 }}
            >
              <Users size={18} />
              I'm a Recruiter
            </motion.button>
          </div>
          <p className="text-white/30 text-sm mt-6">
            <Globe size={13} className="inline mr-1" />
            Used in 50+ countries • GDPR compliant • 256-bit encryption
          </p>
        </motion.div>
      </div>
    </section>
  );
};

// ============================================================
// LANDING PAGE
// ============================================================
const LandingPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-dark-bg">
      <Navbar />
      <HeroSection />
      <CompaniesSection />
      <FeaturesSection />
      <HowItWorks />
      <PricingSection />
      <TestimonialsSection />
      <CTASection />
      <Footer />
    </div>
  );
};

export default LandingPage;
