import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Users, BarChart3, Shield, TrendingUp, Database,
  Activity, AlertCircle, CheckCircle, Settings, Search,
  Download, RefreshCw, Eye, Ban, DollarSign
} from 'lucide-react';
import Sidebar from '../../components/layout/Sidebar';
import { StatCard } from '../../components/ui/SharedComponents';
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, LineChart, Line
} from 'recharts';

const AdminPanel: React.FC = () => {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'analytics' | 'subscriptions'>('overview');

  const users = [
    { id: '1', name: 'Alex Johnson', email: 'alex@example.com', role: 'candidate', plan: 'pro', status: 'active', scans: 23, joinedAt: '2024-01-15' },
    { id: '2', name: 'Sarah Mitchell', email: 'sarah@example.com', role: 'recruiter', plan: 'recruiter', status: 'active', scans: 156, joinedAt: '2024-01-10' },
    { id: '3', name: 'Priya Sharma', email: 'priya@example.com', role: 'candidate', plan: 'free', status: 'active', scans: 3, joinedAt: '2024-02-01' },
    { id: '4', name: 'Marcus Lee', email: 'marcus@example.com', role: 'candidate', plan: 'pro', status: 'active', scans: 45, joinedAt: '2024-01-20' },
    { id: '5', name: 'Emma Wilson', email: 'emma@example.com', role: 'recruiter', plan: 'recruiter', status: 'inactive', scans: 89, joinedAt: '2024-01-05' },
  ];

  const analyticsData = [
    { date: '2024-01', users: 1200, scans: 4500, revenue: 8900 },
    { date: '2024-02', users: 2100, scans: 7200, revenue: 15400 },
    { date: '2024-03', users: 3400, scans: 12000, revenue: 23100 },
    { date: '2024-04', users: 4800, scans: 18500, revenue: 34200 },
    { date: '2024-05', users: 6200, scans: 25000, revenue: 48000 },
    { date: '2024-06', users: 8100, scans: 34000, revenue: 61500 },
  ];

  const aiUsageData = [
    { hour: '00:00', requests: 120 },
    { hour: '04:00', requests: 45 },
    { hour: '08:00', requests: 890 },
    { hour: '12:00', requests: 1240 },
    { hour: '16:00', requests: 980 },
    { hour: '20:00', requests: 560 },
    { hour: '23:00', requests: 230 },
  ];

  const tabs = [
    { id: 'overview', label: 'Overview', icon: BarChart3 },
    { id: 'users', label: 'Users', icon: Users },
    { id: 'analytics', label: 'Analytics', icon: TrendingUp },
    { id: 'subscriptions', label: 'Revenue', icon: DollarSign },
  ];

  const planColors = { free: 'bg-white/10 text-white/50', pro: 'bg-primary-500/20 text-primary-400', recruiter: 'bg-accent-purple/20 text-purple-400' };
  const roleColors = { candidate: 'badge-info', recruiter: 'badge-primary', admin: 'badge-warning' };

  return (
    <div className="flex min-h-screen bg-dark-bg">
      <Sidebar isCollapsed={sidebarCollapsed} onToggle={() => setSidebarCollapsed(!sidebarCollapsed)} />

      <main className={`flex-1 transition-all duration-300 ${sidebarCollapsed ? 'ml-16' : 'ml-64'}`}>
        <div className="sticky top-0 z-30 bg-dark-bg/80 backdrop-blur-xl border-b border-dark-border px-6 py-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-xl font-bold text-white flex items-center gap-2">
                <Shield size={20} className="text-primary-400" />
                Admin Panel
              </h1>
              <p className="text-white/50 text-sm">Platform management & analytics</p>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-emerald-400 text-xs font-medium">System Healthy</span>
              </div>
            </div>
          </div>

          <div className="flex gap-1">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as typeof activeTab)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                    activeTab === tab.id
                      ? 'bg-primary-600/20 text-primary-400 border border-primary-500/30'
                      : 'text-white/50 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Icon size={15} />
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>

        <div className="p-6">
          {activeTab === 'overview' && (
            <motion.div
              key="overview"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <StatCard label="Total Users" value="8,127" change="23%" positive icon={<Users size={20} />} color="primary" />
                <StatCard label="Scans Today" value="1,456" change="15%" positive icon={<Activity size={20} />} color="cyan" />
                <StatCard label="Monthly Revenue" value="$61.5K" change="18%" positive icon={<DollarSign size={20} />} color="emerald" />
                <StatCard label="Active Subscriptions" value="2,341" change="8%" positive icon={<CheckCircle size={20} />} color="purple" />
              </div>

              {/* System Status */}
              <div className="glass-card rounded-2xl p-5 border border-white/5">
                <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                  <Database size={18} className="text-primary-400" />
                  System Status
                </h3>
                <div className="grid md:grid-cols-3 gap-4">
                  {[
                    { name: 'API Server', status: 'operational', uptime: '99.99%', latency: '45ms' },
                    { name: 'AI Engine', status: 'operational', uptime: '99.95%', latency: '2.3s' },
                    { name: 'Database', status: 'operational', uptime: '100%', latency: '12ms' },
                  ].map((service, i) => (
                    <div key={i} className="p-4 rounded-xl bg-white/3 border border-white/5">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-white font-medium text-sm">{service.name}</span>
                        <div className="flex items-center gap-1">
                          <div className="w-2 h-2 rounded-full bg-emerald-400" />
                          <span className="text-emerald-400 text-xs capitalize">{service.status}</span>
                        </div>
                      </div>
                      <div className="flex justify-between text-xs text-white/50">
                        <span>Uptime: {service.uptime}</span>
                        <span>Latency: {service.latency}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Growth Chart */}
              <div className="glass-card rounded-2xl p-5 border border-white/5">
                <h3 className="text-white font-semibold mb-4">Platform Growth</h3>
                <ResponsiveContainer width="100%" height={220}>
                  <AreaChart data={analyticsData}>
                    <defs>
                      <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="g2" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                    <XAxis dataKey="date" tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11 }} />
                    <YAxis tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11 }} />
                    <Tooltip contentStyle={{ background: '#111118', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }} />
                    <Area type="monotone" dataKey="users" stroke="#6366f1" fill="url(#g1)" strokeWidth={2} name="Users" />
                    <Area type="monotone" dataKey="scans" stroke="#10b981" fill="url(#g2)" strokeWidth={2} name="Scans" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              {/* AI Usage */}
              <div className="glass-card rounded-2xl p-5 border border-white/5">
                <h3 className="text-white font-semibold mb-4">AI Engine Usage (Today)</h3>
                <ResponsiveContainer width="100%" height={160}>
                  <BarChart data={aiUsageData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                    <XAxis dataKey="hour" tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11 }} />
                    <YAxis tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11 }} />
                    <Tooltip contentStyle={{ background: '#111118', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }} />
                    <Bar dataKey="requests" fill="#a855f7" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </motion.div>
          )}

          {activeTab === 'users' && (
            <motion.div
              key="users"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-4"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="flex-1 relative">
                  <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/40" />
                  <input className="input-field pl-9 text-sm py-2.5" placeholder="Search users..." />
                </div>
                <button className="px-4 py-2.5 glass rounded-xl border border-white/10 text-white/60 hover:text-white text-sm flex items-center gap-2">
                  <Download size={14} /> Export
                </button>
              </div>

              <div className="glass-card rounded-2xl border border-white/5 overflow-hidden">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-white/5">
                      <th className="text-left text-white/50 text-xs font-medium px-5 py-3 uppercase tracking-wider">User</th>
                      <th className="text-left text-white/50 text-xs font-medium px-5 py-3 uppercase tracking-wider">Role</th>
                      <th className="text-left text-white/50 text-xs font-medium px-5 py-3 uppercase tracking-wider">Plan</th>
                      <th className="text-left text-white/50 text-xs font-medium px-5 py-3 uppercase tracking-wider">Scans</th>
                      <th className="text-left text-white/50 text-xs font-medium px-5 py-3 uppercase tracking-wider">Joined</th>
                      <th className="text-left text-white/50 text-xs font-medium px-5 py-3 uppercase tracking-wider">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map((user, i) => (
                      <motion.tr
                        key={user.id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: i * 0.05 }}
                        className="border-b border-white/5 hover:bg-white/3 transition-colors"
                      >
                        <td className="px-5 py-3">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary-500 to-accent-purple flex items-center justify-center text-xs font-bold text-white">
                              {user.name[0]}
                            </div>
                            <div>
                              <p className="text-white text-sm font-medium">{user.name}</p>
                              <p className="text-white/40 text-xs">{user.email}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-5 py-3">
                          <span className={`badge capitalize ${roleColors[user.role as keyof typeof roleColors] || 'badge-info'}`}>{user.role}</span>
                        </td>
                        <td className="px-5 py-3">
                          <span className={`badge capitalize ${planColors[user.plan as keyof typeof planColors] || 'bg-white/10 text-white/50'}`}>
                            {user.plan}
                          </span>
                        </td>
                        <td className="px-5 py-3">
                          <span className="text-white/70 text-sm">{user.scans}</span>
                        </td>
                        <td className="px-5 py-3">
                          <span className="text-white/40 text-xs">{user.joinedAt}</span>
                        </td>
                        <td className="px-5 py-3">
                          <div className="flex items-center gap-1">
                            <button className="p-1.5 rounded hover:bg-white/10 text-white/40 hover:text-white transition-colors">
                              <Eye size={13} />
                            </button>
                            <button className="p-1.5 rounded hover:bg-red-500/20 text-white/40 hover:text-red-400 transition-colors">
                              <Ban size={13} />
                            </button>
                          </div>
                        </td>
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}

          {activeTab === 'analytics' && (
            <motion.div
              key="analytics"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <div className="grid md:grid-cols-2 gap-6">
                <div className="glass-card rounded-2xl p-5 border border-white/5">
                  <h3 className="text-white font-semibold mb-4">User Growth</h3>
                  <ResponsiveContainer width="100%" height={200}>
                    <LineChart data={analyticsData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                      <XAxis dataKey="date" tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11 }} />
                      <YAxis tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11 }} />
                      <Tooltip contentStyle={{ background: '#111118', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }} />
                      <Line type="monotone" dataKey="users" stroke="#6366f1" strokeWidth={2} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>

                <div className="glass-card rounded-2xl p-5 border border-white/5">
                  <h3 className="text-white font-semibold mb-4">Resume Scans</h3>
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={analyticsData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                      <XAxis dataKey="date" tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11 }} />
                      <YAxis tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11 }} />
                      <Tooltip contentStyle={{ background: '#111118', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }} />
                      <Bar dataKey="scans" fill="#22d3ee" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'subscriptions' && (
            <motion.div
              key="subscriptions"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <div className="grid grid-cols-3 gap-4">
                <div className="glass-card rounded-2xl p-5 border border-white/5">
                  <p className="text-white/50 text-sm mb-1">Free Plan</p>
                  <p className="text-3xl font-bold text-white">5,786</p>
                  <p className="text-white/30 text-xs mt-1">Active users</p>
                </div>
                <div className="glass-card rounded-2xl p-5 border border-primary-500/30 bg-primary-600/5">
                  <p className="text-primary-400 text-sm mb-1">Pro Plan ($19/mo)</p>
                  <p className="text-3xl font-bold text-white">1,892</p>
                  <p className="text-emerald-400 text-xs mt-1">$35.9k MRR</p>
                </div>
                <div className="glass-card rounded-2xl p-5 border border-accent-purple/30 bg-accent-purple/5">
                  <p className="text-purple-400 text-sm mb-1">Recruiter Plan ($79/mo)</p>
                  <p className="text-3xl font-bold text-white">449</p>
                  <p className="text-emerald-400 text-xs mt-1">$35.5k MRR</p>
                </div>
              </div>

              <div className="glass-card rounded-2xl p-5 border border-white/5">
                <h3 className="text-white font-semibold mb-4">Monthly Recurring Revenue</h3>
                <ResponsiveContainer width="100%" height={200}>
                  <AreaChart data={analyticsData}>
                    <defs>
                      <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                    <XAxis dataKey="date" tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11 }} />
                    <YAxis tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11 }} />
                    <Tooltip contentStyle={{ background: '#111118', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }} />
                    <Area type="monotone" dataKey="revenue" stroke="#10b981" fill="url(#revGrad)" strokeWidth={2} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </motion.div>
          )}
        </div>
      </main>
    </div>
  );
};

export default AdminPanel;
