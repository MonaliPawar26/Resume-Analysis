import React, { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { BrainCircuit, Mail, Lock, Eye, EyeOff, ArrowRight, AlertCircle } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';

const LoginPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuthStore();
  const navigate = useNavigate();

  const demoAccounts = [
    { label: 'Candidate Demo', email: 'candidate@demo.com', role: 'candidate' },
    { label: 'Recruiter Demo', email: 'recruiter@demo.com', role: 'recruiter' },
    { label: 'Admin Demo', email: 'admin@demo.com', role: 'admin' },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const success = await login(email, password);
      if (success) {
        const { user } = useAuthStore.getState();
        if (user?.role === 'admin') navigate('/admin');
        else if (user?.role === 'recruiter') navigate('/recruiter');
        else navigate('/dashboard');
      } else {
        setError('Invalid credentials. Try the demo accounts below.');
      }
    } catch {
      setError('An error occurred. Please try again.');
    }
    setLoading(false);
  };

  const handleDemoLogin = async (demoEmail: string) => {
    setEmail(demoEmail);
    setLoading(true);
    const success = await login(demoEmail, 'demo123');
    if (success) {
      const { user } = useAuthStore.getState();
      if (user?.role === 'admin') navigate('/admin');
      else if (user?.role === 'recruiter') navigate('/recruiter');
      else navigate('/dashboard');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-dark-bg flex items-center justify-center relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-primary-600/15 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-0 w-64 h-64 bg-accent-purple/15 rounded-full blur-3xl" />

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md mx-4 z-10"
      >
        {/* Logo */}
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2.5 mb-6">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary-500 to-accent-purple flex items-center justify-center shadow-glow">
              <BrainCircuit size={22} className="text-white" />
            </div>
            <span className="text-2xl font-bold text-white">ResumeAI</span>
          </Link>
          <h1 className="text-2xl font-bold text-white mb-2">Welcome back</h1>
          <p className="text-white/50 text-sm">Sign in to your account to continue</p>
        </div>

        {/* Demo Accounts */}
        <div className="glass-card rounded-2xl p-4 mb-4 border border-primary-500/20">
          <p className="text-xs text-white/50 mb-3 font-medium uppercase tracking-wider">⚡ Quick Demo Access</p>
          <div className="grid grid-cols-3 gap-2">
            {demoAccounts.map((demo) => (
              <button
                key={demo.email}
                onClick={() => handleDemoLogin(demo.email)}
                className="py-2 px-2 glass rounded-xl border border-white/10 hover:border-primary-500/40 transition-all text-center"
              >
                <p className="text-white text-xs font-semibold">{demo.label.split(' ')[0]}</p>
                <p className="text-white/40 text-[10px] capitalize">{demo.role}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Login Form */}
        <div className="glass-card rounded-2xl p-6 border border-white/10">
          <form onSubmit={handleSubmit} className="space-y-5">
            {error && (
              <motion.div
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex items-center gap-2 p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm"
              >
                <AlertCircle size={16} />
                {error}
              </motion.div>
            )}

            <div>
              <label className="text-white/70 text-sm font-medium block mb-1.5">Email Address</label>
              <div className="relative">
                <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/30" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="input-field pl-10"
                  placeholder="you@example.com"
                  required
                />
              </div>
            </div>

            <div>
              <label className="text-white/70 text-sm font-medium block mb-1.5">Password</label>
              <div className="relative">
                <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/30" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="input-field pl-10 pr-10"
                  placeholder="••••••••"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/70 transition-colors"
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 text-white/60 text-sm">
                <input type="checkbox" className="w-4 h-4 rounded accent-primary-500" />
                Remember me
              </label>
              <a href="#" className="text-primary-400 text-sm hover:text-primary-300 transition-colors">
                Forgot password?
              </a>
            </div>

            <motion.button
              type="submit"
              disabled={loading}
              className="w-full btn-primary py-3.5 flex items-center justify-center gap-2"
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.99 }}
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin" />
              ) : (
                <>Sign In <ArrowRight size={16} /></>
              )}
            </motion.button>
          </form>

          <div className="mt-5 text-center text-white/50 text-sm">
            Don't have an account?{' '}
            <Link to="/register" className="text-primary-400 hover:text-primary-300 transition-colors font-medium">
              Sign up free
            </Link>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default LoginPage;
