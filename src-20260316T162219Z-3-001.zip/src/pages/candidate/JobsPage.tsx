import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Briefcase, MapPin, DollarSign, Clock, Building2,
  Star, Filter, Search, TrendingUp, ArrowRight,
  Bookmark, BookmarkCheck, ExternalLink, Zap, ChevronDown
} from 'lucide-react';
import Sidebar from '../../components/layout/Sidebar';

const JOBS_DATA = [
  { id: 1, title: 'Senior Frontend Engineer', company: 'Stripe', location: 'San Francisco, CA', salary: '$160k–$200k', type: 'Full-time', remote: true, match: 92, tags: ['React', 'TypeScript', 'Next.js'], logo: 'S', color: 'from-violet-500 to-purple-600', postedAgo: '2h ago', applicants: 48 },
  { id: 2, title: 'Full Stack Developer', company: 'Airbnb', location: 'New York, NY', salary: '$140k–$180k', type: 'Full-time', remote: false, match: 87, tags: ['React', 'Node.js', 'Python'], logo: 'A', color: 'from-rose-500 to-pink-600', postedAgo: '5h ago', applicants: 123 },
  { id: 3, title: 'React Native Developer', company: 'Uber', location: 'Remote', salary: '$130k–$160k', type: 'Full-time', remote: true, match: 83, tags: ['React Native', 'TypeScript', 'Redux'], logo: 'U', color: 'from-gray-600 to-gray-800', postedAgo: '1d ago', applicants: 201 },
  { id: 4, title: 'Software Engineer II', company: 'Google', location: 'Mountain View, CA', salary: '$150k–$220k', type: 'Full-time', remote: false, match: 79, tags: ['JavaScript', 'Go', 'Kubernetes'], logo: 'G', color: 'from-blue-500 to-cyan-600', postedAgo: '2d ago', applicants: 589 },
  { id: 5, title: 'Frontend Architect', company: 'Vercel', location: 'Remote', salary: '$180k–$240k', type: 'Full-time', remote: true, match: 74, tags: ['React', 'Next.js', 'Performance'], logo: 'V', color: 'from-gray-800 to-black', postedAgo: '3d ago', applicants: 67 },
  { id: 6, title: 'JavaScript Engineer', company: 'GitHub', location: 'Remote', salary: '$120k–$160k', type: 'Full-time', remote: true, match: 71, tags: ['JavaScript', 'Ruby', 'Git'], logo: 'GH', color: 'from-gray-700 to-gray-900', postedAgo: '1w ago', applicants: 304 },
  { id: 7, title: 'Product Engineer', company: 'Linear', location: 'Remote', salary: '$140k–$180k', type: 'Full-time', remote: true, match: 68, tags: ['React', 'TypeScript', 'GraphQL'], logo: 'L', color: 'from-indigo-500 to-violet-600', postedAgo: '1w ago', applicants: 89 },
  { id: 8, title: 'UI Engineer', company: 'Figma', location: 'San Francisco, CA', salary: '$145k–$190k', type: 'Full-time', remote: false, match: 65, tags: ['React', 'Canvas', 'WebGL'], logo: 'F', color: 'from-purple-500 to-violet-500', postedAgo: '2w ago', applicants: 156 },
];

const JobsPage: React.FC = () => {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [search, setSearch] = useState('');
  const [savedJobs, setSavedJobs] = useState<number[]>([]);
  const [filterRemote, setFilterRemote] = useState(false);
  const [sortBy, setSortBy] = useState<'match' | 'recent' | 'salary'>('match');

  const toggleSave = (id: number) => {
    setSavedJobs(prev => prev.includes(id) ? prev.filter(j => j !== id) : [...prev, id]);
  };

  const filtered = JOBS_DATA
    .filter(j => {
      if (search && !j.title.toLowerCase().includes(search.toLowerCase()) && !j.company.toLowerCase().includes(search.toLowerCase())) return false;
      if (filterRemote && !j.remote) return false;
      return true;
    })
    .sort((a, b) => {
      if (sortBy === 'match') return b.match - a.match;
      if (sortBy === 'recent') return a.postedAgo.localeCompare(b.postedAgo);
      return 0;
    });

  return (
    <div className="flex min-h-screen bg-dark-bg">
      <Sidebar isCollapsed={sidebarCollapsed} onToggle={() => setSidebarCollapsed(!sidebarCollapsed)} />

      <main className={`flex-1 transition-all duration-300 ${sidebarCollapsed ? 'ml-16' : 'ml-64'}`}>
        {/* Header */}
        <div className="sticky top-0 z-30 bg-dark-bg/80 backdrop-blur-xl border-b border-dark-border px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-white">Job Matches</h1>
              <p className="text-white/40 text-sm">{filtered.length} jobs matched to your profile</p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setFilterRemote(!filterRemote)}
                className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${filterRemote ? 'bg-primary-600/30 text-primary-400 border border-primary-500/40' : 'glass border border-white/10 text-white/60 hover:text-white'}`}
              >
                🌐 Remote Only
              </button>
              <div className="relative">
                <select
                  value={sortBy}
                  onChange={e => setSortBy(e.target.value as typeof sortBy)}
                  className="appearance-none bg-dark-surface border border-dark-border text-white/70 text-sm rounded-xl px-4 py-2 pr-8 focus:outline-none focus:border-primary-500/60"
                >
                  <option value="match">Best Match</option>
                  <option value="recent">Most Recent</option>
                </select>
                <ChevronDown size={14} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-white/40 pointer-events-none" />
              </div>
            </div>
          </div>
        </div>

        <div className="p-6">
          {/* Search bar */}
          <div className="relative mb-6">
            <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30" />
            <input
              type="text"
              placeholder="Search job titles or companies..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full bg-dark-card border border-dark-border text-white placeholder-white/30 rounded-xl pl-11 pr-4 py-3 focus:outline-none focus:border-primary-500/60 transition-colors"
            />
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
            {[
              { label: 'Jobs Matched', value: '8', icon: Briefcase, color: 'text-primary-400' },
              { label: 'Avg. Match', value: '77%', icon: TrendingUp, color: 'text-emerald-400' },
              { label: 'Remote Jobs', value: '5', icon: MapPin, color: 'text-accent-cyan' },
              { label: 'Saved', value: savedJobs.length.toString(), icon: Star, color: 'text-amber-400' },
            ].map(stat => {
              const Icon = stat.icon;
              return (
                <motion.div
                  key={stat.label}
                  className="glass-card rounded-xl p-4"
                  whileHover={{ scale: 1.02 }}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <Icon size={14} className={stat.color} />
                    <span className="text-white/40 text-xs">{stat.label}</span>
                  </div>
                  <div className="text-2xl font-bold text-white">{stat.value}</div>
                </motion.div>
              );
            })}
          </div>

          {/* Job cards */}
          <div className="space-y-4">
            {filtered.map((job, i) => (
              <motion.div
                key={job.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="glass-card rounded-2xl p-5 hover:border-primary-500/30 border border-transparent transition-all group"
                whileHover={{ scale: 1.005 }}
              >
                <div className="flex items-start gap-4">
                  {/* Company logo */}
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${job.color} flex items-center justify-center text-white font-bold text-sm shrink-0`}>
                    {job.logo}
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h3 className="text-white font-semibold group-hover:text-primary-300 transition-colors">{job.title}</h3>
                        <div className="flex items-center gap-3 mt-1 text-sm text-white/50">
                          <span className="flex items-center gap-1">
                            <Building2 size={12} />
                            {job.company}
                          </span>
                          <span className="flex items-center gap-1">
                            <MapPin size={12} />
                            {job.location}
                          </span>
                          <span className="flex items-center gap-1">
                            <DollarSign size={12} />
                            {job.salary}
                          </span>
                        </div>
                      </div>

                      {/* Match score */}
                      <div className="shrink-0 flex flex-col items-end gap-2">
                        <div className={`px-3 py-1 rounded-full text-sm font-bold ${
                          job.match >= 85 ? 'bg-emerald-500/20 text-emerald-400' :
                          job.match >= 70 ? 'bg-primary-500/20 text-primary-400' :
                          'bg-amber-500/20 text-amber-400'
                        }`}>
                          {job.match}% match
                        </div>
                        <div className="flex items-center gap-1 text-xs text-white/30">
                          <Clock size={10} />
                          {job.postedAgo}
                        </div>
                      </div>
                    </div>

                    {/* Tags */}
                    <div className="flex items-center gap-2 mt-3 flex-wrap">
                      {job.remote && (
                        <span className="px-2 py-0.5 rounded-full bg-cyan-500/10 text-accent-cyan text-xs font-medium">
                          🌐 Remote
                        </span>
                      )}
                      {job.tags.map(tag => (
                        <span key={tag} className="px-2 py-0.5 rounded-full bg-white/5 text-white/50 text-xs">
                          {tag}
                        </span>
                      ))}
                      <span className="text-xs text-white/30 ml-auto">{job.applicants} applicants</span>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-2 mt-4">
                      <motion.button
                        className="btn-primary flex items-center gap-2 text-sm py-2"
                        whileHover={{ scale: 1.03 }}
                        whileTap={{ scale: 0.97 }}
                      >
                        <Zap size={14} />
                        Quick Apply
                        <ArrowRight size={14} />
                      </motion.button>
                      <button
                        onClick={() => toggleSave(job.id)}
                        className={`p-2 rounded-xl transition-all ${savedJobs.includes(job.id) ? 'bg-amber-500/20 text-amber-400' : 'glass border border-white/10 text-white/40 hover:text-white'}`}
                      >
                        {savedJobs.includes(job.id) ? <BookmarkCheck size={16} /> : <Bookmark size={16} />}
                      </button>
                      <button className="p-2 rounded-xl glass border border-white/10 text-white/40 hover:text-white transition-all">
                        <ExternalLink size={16} />
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}

            {filtered.length === 0 && (
              <div className="text-center py-20">
                <Search size={40} className="text-white/20 mx-auto mb-4" />
                <p className="text-white/50">No jobs found matching your search</p>
                <button onClick={() => { setSearch(''); setFilterRemote(false); }} className="mt-3 text-primary-400 text-sm hover:text-primary-300">
                  Clear filters
                </button>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default JobsPage;
