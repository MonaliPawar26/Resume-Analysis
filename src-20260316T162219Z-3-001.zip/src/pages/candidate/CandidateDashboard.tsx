import React, { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useDropzone } from 'react-dropzone';
import {
  Upload, FileText, CheckCircle, AlertCircle, AlertTriangle,
  Download, Sparkles, ChevronDown, ChevronUp, TrendingUp,
  Award, Target, BarChart3, Zap, Search, Brain, Shield
} from 'lucide-react';
import { useResumeStore } from '../../store/resumeStore';
import { useJobStore, getTopJobMatches } from '../../store/jobStore';
import { useAuthStore } from '../../store/authStore';
import {
  ScoreRing, ProgressBar, TiltCard, Badge, Skeleton, StatCard
} from '../../components/ui/SharedComponents';
import Sidebar from '../../components/layout/Sidebar';
import {
  RadarChart, PolarGrid, PolarAngleAxis, Radar, ResponsiveContainer,
  BarChart, Bar, XAxis, YAxis, Tooltip, AreaChart, Area, CartesianGrid
} from 'recharts';

const CandidateDashboard: React.FC = () => {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'analysis' | 'jobs' | 'rewrite'>('overview');
  const [expandedSection, setExpandedSection] = useState<string | null>(null);
  const { user } = useAuthStore();
  const { analyses, currentAnalysis, isAnalyzing, uploadFile } = useResumeStore();
  const { jobs } = useJobStore();

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0 && user) {
      await uploadFile(acceptedFiles[0], user.id);
      setActiveTab('analysis');
    }
  }, [user, uploadFile]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'application/pdf': ['.pdf'], 'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'] },
    maxFiles: 1,
  });

  const topMatches = currentAnalysis ? getTopJobMatches(currentAnalysis, jobs) : [];

  const scoreData = currentAnalysis?.sectionScores.map(s => ({
    section: s.section.split(' ')[0],
    score: s.score,
  })) || [];

  const radarData = currentAnalysis?.skills.slice(0, 6).map(s => ({
    skill: s.name,
    level: s.level === 'expert' ? 100 : s.level === 'advanced' ? 80 : s.level === 'intermediate' ? 60 : 40,
  })) || [];

  const weeklyData = [
    { day: 'Mon', scans: 2, matches: 5 },
    { day: 'Tue', scans: 1, matches: 3 },
    { day: 'Wed', scans: 3, matches: 8 },
    { day: 'Thu', scans: 2, matches: 6 },
    { day: 'Fri', scans: 4, matches: 12 },
    { day: 'Sat', scans: 1, matches: 2 },
    { day: 'Sun', scans: 0, matches: 1 },
  ];

  const tabs = [
    { id: 'overview', label: 'Overview', icon: BarChart3 },
    { id: 'analysis', label: 'Analysis', icon: Brain },
    { id: 'jobs', label: 'Job Matches', icon: Search },
    { id: 'rewrite', label: 'AI Rewrite', icon: Sparkles },
  ];

  return (
    <div className="flex min-h-screen bg-dark-bg">
      <Sidebar isCollapsed={sidebarCollapsed} onToggle={() => setSidebarCollapsed(!sidebarCollapsed)} />

      <main className={`flex-1 transition-all duration-300 ${sidebarCollapsed ? 'ml-16' : 'ml-64'}`}>
        {/* Top Header */}
        <div className="sticky top-0 z-30 bg-dark-bg/80 backdrop-blur-xl border-b border-dark-border px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-white">
                Welcome back, {user?.name.split(' ')[0]}! 👋
              </h1>
              <p className="text-white/50 text-sm">
                {currentAnalysis
                  ? `Last scan: ${new Date(currentAnalysis.uploadedAt).toLocaleDateString()}`
                  : 'Upload your resume to get started'}
              </p>
            </div>
            <div className="flex items-center gap-3">
              {user?.plan === 'free' && (
                <span className="px-3 py-1 rounded-full bg-yellow-500/20 text-yellow-400 text-xs font-medium border border-yellow-500/30">
                  {user.scansLimit - user.scansUsed} scans remaining
                </span>
              )}
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-primary-500 to-accent-purple flex items-center justify-center text-sm font-bold text-white">
                {user?.name[0].toUpperCase()}
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex gap-1 mt-4">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as typeof activeTab)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                    activeTab === tab.id
                      ? 'bg-primary-600/20 text-primary-400 border border-primary-500/30'
                      : 'text-white/50 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Icon size={15} />
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>

        <div className="p-6">
          <AnimatePresence mode="wait">
            {/* ---- OVERVIEW TAB ---- */}
            {activeTab === 'overview' && (
              <motion.div
                key="overview"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-6"
              >
                {/* Upload Area */}
                {!currentAnalysis && !isAnalyzing && (
                  <div
                    {...getRootProps()}
                    className={`dropzone ${isDragActive ? 'dropzone-active' : ''}`}
                  >
                    <input {...getInputProps()} />
                    <div className="w-16 h-16 rounded-2xl bg-primary-600/20 border border-primary-500/30 flex items-center justify-center mb-4">
                      <Upload size={28} className="text-primary-400" />
                    </div>
                    <h3 className="text-white font-semibold text-lg mb-2">
                      {isDragActive ? 'Drop your resume here' : 'Upload Your Resume'}
                    </h3>
                    <p className="text-white/50 text-sm mb-4">Drag & drop or click to browse • PDF, DOCX supported</p>
                    <button className="btn-primary text-sm py-2.5 px-6">Choose File</button>
                  </div>
                )}

                {/* Analyzing State */}
                {isAnalyzing && (
                  <div className="glass-card rounded-2xl p-10 text-center border border-primary-500/20">
                    <div className="relative mx-auto w-20 h-20 mb-6">
                      <div className="absolute inset-0 rounded-full border-2 border-primary-500/20 border-t-primary-500 animate-spin" />
                      <div className="absolute inset-2 rounded-full border-2 border-accent-purple/20 border-t-accent-purple animate-spin" style={{ animationDuration: '1.5s', animationDirection: 'reverse' }} />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <Brain size={24} className="text-primary-400" />
                      </div>
                    </div>
                    <h3 className="text-white font-semibold text-xl mb-2">AI Analyzing Your Resume</h3>
                    <p className="text-white/50 text-sm">Extracting skills, calculating ATS score, finding job matches...</p>
                    <div className="mt-4 space-y-2">
                      {['Parsing resume structure...', 'Extracting skills & keywords...', 'Calculating ATS score...', 'Finding job matches...'].map((step, i) => (
                        <motion.div
                          key={step}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: i * 0.7 }}
                          className="flex items-center gap-2 text-sm text-white/50 justify-center"
                        >
                          <motion.div
                            className="w-4 h-4 rounded-full bg-primary-500/20 border border-primary-500/50 flex items-center justify-center"
                            animate={{ backgroundColor: ['rgba(99,102,241,0.2)', 'rgba(99,102,241,0.6)', 'rgba(99,102,241,0.2)'] }}
                            transition={{ delay: i * 0.7, duration: 0.8 }}
                          >
                            <div className="w-1.5 h-1.5 rounded-full bg-primary-400" />
                          </motion.div>
                          {step}
                        </motion.div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Stats Grid */}
                {currentAnalysis && (
                  <>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <StatCard label="Resume Score" value={currentAnalysis.overallScore} change="12%" positive icon={<Award size={20} />} color="primary" />
                      <StatCard label="Skill Match" value={`${currentAnalysis.skillMatchPercent}%`} change="8%" positive icon={<Target size={20} />} color="cyan" />
                      <StatCard label="ATS Score" value={currentAnalysis.atsScore} change="5%" positive icon={<Shield size={20} />} color="purple" />
                      <StatCard label="Keywords" value={`${currentAnalysis.keywordDensityPercent}%`} change="3%" positive icon={<Zap size={20} />} color="emerald" />
                    </div>

                    {/* Charts Row */}
                    <div className="grid md:grid-cols-2 gap-6">
                      {/* Section Scores Bar Chart */}
                      <div className="glass-card rounded-2xl p-5 border border-white/5">
                        <h3 className="text-white font-semibold mb-4">Section Scores</h3>
                        <ResponsiveContainer width="100%" height={200}>
                          <BarChart data={scoreData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                            <XAxis dataKey="section" tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11 }} />
                            <YAxis tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11 }} />
                            <Tooltip
                              contentStyle={{ background: '#111118', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }}
                              labelStyle={{ color: 'white' }}
                            />
                            <Bar dataKey="score" fill="#6366f1" radius={[4, 4, 0, 0]} />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>

                      {/* Skills Radar */}
                      <div className="glass-card rounded-2xl p-5 border border-white/5">
                        <h3 className="text-white font-semibold mb-4">Skills Proficiency</h3>
                        <ResponsiveContainer width="100%" height={200}>
                          <RadarChart data={radarData}>
                            <PolarGrid stroke="rgba(255,255,255,0.05)" />
                            <PolarAngleAxis dataKey="skill" tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11 }} />
                            <Radar name="Level" dataKey="level" stroke="#6366f1" fill="#6366f1" fillOpacity={0.2} />
                          </RadarChart>
                        </ResponsiveContainer>
                      </div>
                    </div>

                    {/* Quick Upload Another */}
                    <div
                      {...getRootProps()}
                      className="border border-dashed border-white/10 rounded-2xl p-4 text-center hover:border-primary-500/30 hover:bg-primary-500/5 transition-all cursor-pointer"
                    >
                      <input {...getInputProps()} />
                      <p className="text-white/50 text-sm">
                        <Upload size={14} className="inline mr-1" />
                        Upload a new resume to compare
                      </p>
                    </div>
                  </>
                )}
              </motion.div>
            )}

            {/* ---- ANALYSIS TAB ---- */}
            {activeTab === 'analysis' && currentAnalysis && (
              <motion.div
                key="analysis"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-6"
              >
                {/* Scores Row */}
                <div className="grid md:grid-cols-4 gap-6">
                  <div className="glass-card rounded-2xl p-6 flex flex-col items-center border border-white/5">
                    <ScoreRing score={currentAnalysis.overallScore} label="Overall" />
                    <p className="text-white font-semibold mt-3">Resume Score</p>
                    <p className="text-white/50 text-xs text-center">
                      {currentAnalysis.overallScore >= 80 ? 'Excellent!' : currentAnalysis.overallScore >= 60 ? 'Good, needs improvements' : 'Needs significant work'}
                    </p>
                  </div>
                  <div className="glass-card rounded-2xl p-6 flex flex-col items-center border border-white/5">
                    <ScoreRing score={currentAnalysis.skillMatchPercent} label="Skills" color="#22d3ee" />
                    <p className="text-white font-semibold mt-3">Skill Match</p>
                    <p className="text-white/50 text-xs">vs industry average</p>
                  </div>
                  <div className="glass-card rounded-2xl p-6 flex flex-col items-center border border-white/5">
                    <ScoreRing score={currentAnalysis.atsScore} label="ATS" color="#a855f7" />
                    <p className="text-white font-semibold mt-3">ATS Score</p>
                    <p className="text-white/50 text-xs">Automation compatibility</p>
                  </div>
                  <div className="glass-card rounded-2xl p-6 flex flex-col items-center border border-white/5">
                    <ScoreRing score={currentAnalysis.keywordDensityPercent} label="Keywords" color="#10b981" />
                    <p className="text-white font-semibold mt-3">Keyword Density</p>
                    <p className="text-white/50 text-xs">Industry keyword coverage</p>
                  </div>
                </div>

                {/* ATS Issues */}
                <div className="glass-card rounded-2xl p-6 border border-white/5">
                  <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                    <AlertTriangle size={18} className="text-yellow-400" />
                    ATS Issues Detected
                  </h3>
                  <div className="space-y-3">
                    {currentAnalysis.atsIssues.map((issue, i) => (
                      <div key={i} className={`flex items-start gap-3 p-3 rounded-xl ${
                        issue.type === 'critical' ? 'bg-red-500/10 border border-red-500/20' :
                        issue.type === 'warning' ? 'bg-yellow-500/10 border border-yellow-500/20' :
                        'bg-blue-500/10 border border-blue-500/20'
                      }`}>
                        {issue.type === 'critical' ? <AlertCircle size={16} className="text-red-400 mt-0.5" /> :
                         issue.type === 'warning' ? <AlertTriangle size={16} className="text-yellow-400 mt-0.5" /> :
                         <CheckCircle size={16} className="text-blue-400 mt-0.5" />}
                        <div>
                          <p className="text-white text-sm font-medium">{issue.message}</p>
                          <p className="text-white/50 text-xs mt-0.5">{issue.suggestion}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Section Scores */}
                <div className="glass-card rounded-2xl p-6 border border-white/5">
                  <h3 className="text-white font-semibold mb-5 flex items-center gap-2">
                    <BarChart3 size={18} className="text-primary-400" />
                    Section Analysis
                  </h3>
                  <div className="space-y-4">
                    {currentAnalysis.sectionScores.map((section, i) => (
                      <div key={i}>
                        <ProgressBar
                          value={section.score}
                          label={section.section}
                          color={section.score >= 80 ? '#10b981' : section.score >= 60 ? '#6366f1' : '#f59e0b'}
                        />
                      </div>
                    ))}
                  </div>
                </div>

                {/* Missing Keywords */}
                <div className="glass-card rounded-2xl p-6 border border-white/5">
                  <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                    <Target size={18} className="text-accent-purple" />
                    Missing Keywords
                  </h3>
                  <p className="text-white/50 text-sm mb-4">Add these keywords to improve your ATS score and visibility:</p>
                  <div className="flex flex-wrap gap-2">
                    {currentAnalysis.missingKeywords.map((kw, i) => (
                      <span key={i} className="px-3 py-1.5 rounded-lg bg-red-500/10 border border-red-500/30 text-red-300 text-xs font-medium">
                        + {kw}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Improvement Suggestions */}
                <div className="glass-card rounded-2xl p-6 border border-white/5">
                  <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                    <TrendingUp size={18} className="text-accent-cyan" />
                    AI Improvement Suggestions
                  </h3>
                  <div className="space-y-3">
                    {currentAnalysis.suggestions.map((sug, i) => (
                      <div
                        key={i}
                        className={`p-4 rounded-xl border cursor-pointer transition-all ${
                          expandedSection === `sug-${i}` ? 'border-primary-500/40 bg-primary-500/5' : 'border-white/5 hover:border-white/10'
                        }`}
                        onClick={() => setExpandedSection(expandedSection === `sug-${i}` ? null : `sug-${i}`)}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <span className={`badge ${sug.priority === 'high' ? 'badge-danger' : sug.priority === 'medium' ? 'badge-warning' : 'badge-info'}`}>
                              {sug.priority}
                            </span>
                            <span className="text-white text-sm font-medium">{sug.section}: {sug.issue}</span>
                          </div>
                          {expandedSection === `sug-${i}` ? <ChevronUp size={16} className="text-white/40" /> : <ChevronDown size={16} className="text-white/40" />}
                        </div>
                        <AnimatePresence>
                          {expandedSection === `sug-${i}` && (
                            <motion.p
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: 'auto', opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              className="text-white/60 text-sm mt-3 overflow-hidden"
                            >
                              {sug.recommendation}
                            </motion.p>
                          )}
                        </AnimatePresence>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Skills Extracted */}
                <div className="glass-card rounded-2xl p-6 border border-white/5">
                  <h3 className="text-white font-semibold mb-4">Extracted Skills</h3>
                  <div className="flex flex-wrap gap-2">
                    {currentAnalysis.skills.map((skill, i) => (
                      <span
                        key={i}
                        className={`px-3 py-1.5 rounded-lg border text-xs font-medium ${
                          skill.level === 'expert' ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-300' :
                          skill.level === 'advanced' ? 'bg-primary-500/15 border-primary-500/30 text-primary-300' :
                          skill.level === 'intermediate' ? 'bg-accent-purple/15 border-accent-purple/30 text-purple-300' :
                          'bg-white/5 border-white/10 text-white/60'
                        }`}
                      >
                        {skill.name}
                        <span className="ml-1 opacity-60">({skill.level})</span>
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}

            {/* ---- JOBS TAB ---- */}
            {activeTab === 'jobs' && (
              <motion.div
                key="jobs"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-4"
              >
                {!currentAnalysis ? (
                  <div className="glass-card rounded-2xl p-12 text-center border border-white/5">
                    <Search size={40} className="text-white/20 mx-auto mb-4" />
                    <h3 className="text-white font-semibold text-lg mb-2">Upload Resume First</h3>
                    <p className="text-white/50 text-sm">Upload your resume to get personalized job matches</p>
                    <button onClick={() => setActiveTab('overview')} className="btn-primary mt-4 text-sm py-2.5 px-6">
                      Go to Upload
                    </button>
                  </div>
                ) : (
                  <>
                    <p className="text-white/50 text-sm">
                      {topMatches.length} jobs matched based on your resume • Sorted by compatibility
                    </p>
                    {topMatches.map((match, i) => (
                      <motion.div
                        key={match.jobId}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.08 }}
                        className="glass-card rounded-2xl p-5 border border-white/5 hover:border-primary-500/20 transition-all"
                      >
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary-500/20 to-accent-purple/20 border border-primary-500/20 flex items-center justify-center text-lg font-bold text-white">
                                {match.job.company[0]}
                              </div>
                              <div>
                                <h3 className="text-white font-semibold">{match.job.title}</h3>
                                <p className="text-white/50 text-sm">{match.job.company} • {match.job.location}</p>
                              </div>
                            </div>
                            <div className="flex items-center gap-3 mb-3">
                              {match.job.salary && (
                                <span className="text-emerald-400 text-xs font-medium">{match.job.salary}</span>
                              )}
                              <span className="text-white/40 text-xs">{match.job.experienceLevel}</span>
                            </div>
                            <ProgressBar value={match.skillMatchPercent} label="Skill Match" height="h-1.5" showValue={false} />
                            <div className="mt-3 flex flex-wrap gap-1.5">
                              {match.matchedSkills.slice(0, 4).map((skill, j) => (
                                <span key={j} className="px-2 py-0.5 rounded bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs">
                                  ✓ {skill}
                                </span>
                              ))}
                              {match.missingSkills.slice(0, 3).map((skill, j) => (
                                <span key={j} className="px-2 py-0.5 rounded bg-red-500/10 border border-red-500/20 text-red-400 text-xs">
                                  ✗ {skill}
                                </span>
                              ))}
                            </div>
                          </div>
                          <div className="text-center flex-shrink-0">
                            <div className={`text-3xl font-bold mb-1 ${
                              match.overallScore >= 80 ? 'text-emerald-400' :
                              match.overallScore >= 65 ? 'text-primary-400' :
                              match.overallScore >= 50 ? 'text-yellow-400' : 'text-red-400'
                            }`}>
                              {match.overallScore}%
                            </div>
                            <p className="text-white/40 text-xs">Match</p>
                            <button className="mt-3 px-4 py-1.5 rounded-lg bg-primary-600/20 border border-primary-500/30 text-primary-400 text-xs hover:bg-primary-600/30 transition-all">
                              View Details
                            </button>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </>
                )}
              </motion.div>
            )}

            {/* ---- AI REWRITE TAB ---- */}
            {activeTab === 'rewrite' && (
              <motion.div
                key="rewrite"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-6"
              >
                {!currentAnalysis ? (
                  <div className="glass-card rounded-2xl p-12 text-center border border-white/5">
                    <Sparkles size={40} className="text-white/20 mx-auto mb-4" />
                    <h3 className="text-white font-semibold text-lg mb-2">Upload Resume First</h3>
                    <p className="text-white/50 text-sm">Upload your resume to get AI-powered rewrite suggestions</p>
                  </div>
                ) : (
                  <>
                    <div className="glass-card rounded-2xl p-6 border border-primary-500/20 bg-gradient-to-br from-primary-600/10 to-transparent">
                      <div className="flex items-center gap-3 mb-4">
                        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary-500 to-accent-purple flex items-center justify-center">
                          <Sparkles size={18} className="text-white" />
                        </div>
                        <div>
                          <h3 className="text-white font-semibold">AI Resume Rewrite</h3>
                          <p className="text-white/50 text-sm">Optimized version of your professional summary</p>
                        </div>
                      </div>
                      <div className="bg-dark-bg/60 rounded-xl p-5 border border-white/5">
                        <pre className="text-white/80 text-sm leading-relaxed whitespace-pre-wrap font-sans">
                          {currentAnalysis.aiRewrite}
                        </pre>
                      </div>
                      <div className="mt-4 flex items-center gap-3">
                        <button className="btn-primary text-sm py-2 px-5 flex items-center gap-2">
                          <Download size={15} /> Copy to Clipboard
                        </button>
                        <button className="btn-secondary text-sm py-2 px-5">
                          Regenerate
                        </button>
                      </div>
                    </div>

                    <div className="glass-card rounded-2xl p-6 border border-white/5">
                      <h3 className="text-white font-semibold mb-4">Rewrite Specific Section</h3>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
                        {['Summary', 'Experience', 'Skills', 'Achievements'].map((section) => (
                          <button
                            key={section}
                            className="px-3 py-2.5 rounded-xl glass border border-white/10 hover:border-primary-500/30 text-white/70 hover:text-white text-sm transition-all"
                          >
                            {section}
                          </button>
                        ))}
                      </div>
                      <textarea
                        className="input-field h-32 resize-none"
                        placeholder="Paste the section you want AI to rewrite..."
                      />
                      <button className="btn-primary text-sm py-2.5 px-6 mt-3 flex items-center gap-2">
                        <Zap size={15} /> Generate AI Rewrite
                      </button>
                    </div>
                  </>
                )}
              </motion.div>
            )}

            {/* No analysis for analysis/jobs tabs */}
            {(activeTab === 'analysis') && !currentAnalysis && (
              <motion.div
                key="no-analysis"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="glass-card rounded-2xl p-12 text-center border border-white/5"
              >
                <FileText size={40} className="text-white/20 mx-auto mb-4" />
                <h3 className="text-white font-semibold text-lg mb-2">No Resume Analyzed Yet</h3>
                <p className="text-white/50 text-sm mb-4">Upload your resume to see detailed analysis</p>
                <button onClick={() => setActiveTab('overview')} className="btn-primary text-sm py-2.5 px-6">
                  Upload Resume
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
};

export default CandidateDashboard;
