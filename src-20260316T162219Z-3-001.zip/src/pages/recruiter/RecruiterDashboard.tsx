import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Briefcase, Users, BarChart3, TrendingUp, Plus, Search,
  Filter, Download, Star, CheckCircle, XCircle, Eye,
  Building, MapPin, DollarSign, Clock, Award
} from 'lucide-react';
import Sidebar from '../../components/layout/Sidebar';
import { StatCard, ProgressBar, Badge, TiltCard } from '../../components/ui/SharedComponents';
import { useAuthStore } from '../../store/authStore';
import { useJobStore } from '../../store/jobStore';
import { useResumeStore } from '../../store/resumeStore';
import { getTopJobMatches } from '../../store/jobStore';
import { JobDescription } from '../../types';
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, PieChart, Pie, Cell
} from 'recharts';

const RecruiterDashboard: React.FC = () => {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'jobs' | 'candidates' | 'post'>('overview');
  const [showPostJob, setShowPostJob] = useState(false);
  const [newJob, setNewJob] = useState({
    title: '',
    company: '',
    description: '',
    requiredSkills: '',
    preferredSkills: '',
    experienceLevel: '',
    location: '',
    salary: '',
  });

  const { user } = useAuthStore();
  const { jobs, addJob } = useJobStore();
  const { analyses } = useResumeStore();

  const myJobs = jobs.filter(j => j.postedBy === user?.id || j.postedBy === 'user-2');

  const candidates = analyses.length > 0 ? analyses.map((a, i) => ({
    id: a.userId,
    name: ['Alex Johnson', 'Priya Sharma', 'Marcus Lee', 'Sarah Chen'][i % 4],
    role: ['Frontend Engineer', 'Full Stack Dev', 'React Developer', 'Software Engineer'][i % 4],
    score: a.overallScore,
    skills: a.skills.slice(0, 4).map(s => s.name),
    status: ['pending', 'shortlisted', 'rejected', 'hired'][i % 4] as const,
  })) : [
    { id: '1', name: 'Alex Johnson', role: 'Frontend Engineer', score: 87, skills: ['React', 'TypeScript', 'Node.js', 'AWS'], status: 'shortlisted' as const },
    { id: '2', name: 'Priya Sharma', role: 'Full Stack Dev', score: 92, skills: ['React', 'Python', 'Django', 'PostgreSQL'], status: 'pending' as const },
    { id: '3', name: 'Marcus Lee', role: 'React Developer', score: 76, skills: ['React', 'JavaScript', 'CSS', 'Redux'], status: 'pending' as const },
    { id: '4', name: 'Sarah Chen', role: 'Software Engineer', score: 88, skills: ['Node.js', 'TypeScript', 'Docker', 'K8s'], status: 'shortlisted' as const },
    { id: '5', name: 'James Kim', role: 'Backend Engineer', score: 71, skills: ['Python', 'FastAPI', 'MongoDB', 'Redis'], status: 'rejected' as const },
  ];

  const analyticsData = [
    { date: 'Jan', applications: 45, hires: 3 },
    { date: 'Feb', applications: 67, hires: 5 },
    { date: 'Mar', applications: 89, hires: 7 },
    { date: 'Apr', applications: 54, hires: 4 },
    { date: 'May', applications: 120, hires: 9 },
    { date: 'Jun', applications: 98, hires: 8 },
  ];

  const pieData = [
    { name: 'Pending', value: 45, color: '#f59e0b' },
    { name: 'Shortlisted', value: 30, color: '#6366f1' },
    { name: 'Hired', value: 15, color: '#10b981' },
    { name: 'Rejected', value: 10, color: '#ef4444' },
  ];

  const handlePostJob = () => {
    if (newJob.title && newJob.company) {
      addJob({
        title: newJob.title,
        company: newJob.company,
        description: newJob.description,
        requiredSkills: newJob.requiredSkills.split(',').map(s => s.trim()).filter(Boolean),
        preferredSkills: newJob.preferredSkills.split(',').map(s => s.trim()).filter(Boolean),
        experienceLevel: newJob.experienceLevel,
        location: newJob.location,
        salary: newJob.salary,
        postedBy: user?.id,
      });
      setNewJob({ title: '', company: '', description: '', requiredSkills: '', preferredSkills: '', experienceLevel: '', location: '', salary: '' });
      setShowPostJob(false);
      setActiveTab('jobs');
    }
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: BarChart3 },
    { id: 'jobs', label: 'My Jobs', icon: Briefcase },
    { id: 'candidates', label: 'Candidates', icon: Users },
    { id: 'post', label: 'Post Job', icon: Plus },
  ];

  return (
    <div className="flex min-h-screen bg-dark-bg">
      <Sidebar isCollapsed={sidebarCollapsed} onToggle={() => setSidebarCollapsed(!sidebarCollapsed)} />

      <main className={`flex-1 transition-all duration-300 ${sidebarCollapsed ? 'ml-16' : 'ml-64'}`}>
        {/* Header */}
        <div className="sticky top-0 z-30 bg-dark-bg/80 backdrop-blur-xl border-b border-dark-border px-6 py-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-xl font-bold text-white">Recruiter Dashboard</h1>
              <p className="text-white/50 text-sm">{user?.name} • {user?.plan} Plan</p>
            </div>
            <motion.button
              onClick={() => setActiveTab('post')}
              className="btn-primary text-sm py-2.5 px-5 flex items-center gap-2"
              whileHover={{ scale: 1.02 }}
            >
              <Plus size={16} /> Post New Job
            </motion.button>
          </div>

          <div className="flex gap-1">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as typeof activeTab)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                    activeTab === tab.id
                      ? 'bg-primary-600/20 text-primary-400 border border-primary-500/30'
                      : 'text-white/50 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Icon size={15} />
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>

        <div className="p-6">
          <AnimatePresence mode="wait">
            {/* ---- OVERVIEW ---- */}
            {activeTab === 'overview' && (
              <motion.div
                key="overview"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-6"
              >
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <StatCard label="Active Jobs" value={myJobs.length} change="2 new" positive icon={<Briefcase size={20} />} color="primary" />
                  <StatCard label="Total Applicants" value="234" change="18%" positive icon={<Users size={20} />} color="cyan" />
                  <StatCard label="Shortlisted" value="47" change="12%" positive icon={<Star size={20} />} color="purple" />
                  <StatCard label="Hired This Month" value="9" change="3%" positive icon={<Award size={20} />} color="emerald" />
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="glass-card rounded-2xl p-5 border border-white/5">
                    <h3 className="text-white font-semibold mb-4">Applications Over Time</h3>
                    <ResponsiveContainer width="100%" height={200}>
                      <AreaChart data={analyticsData}>
                        <defs>
                          <linearGradient id="gradientArea" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                            <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                        <XAxis dataKey="date" tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11 }} />
                        <YAxis tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 11 }} />
                        <Tooltip contentStyle={{ background: '#111118', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }} />
                        <Area type="monotone" dataKey="applications" stroke="#6366f1" fill="url(#gradientArea)" strokeWidth={2} />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>

                  <div className="glass-card rounded-2xl p-5 border border-white/5">
                    <h3 className="text-white font-semibold mb-4">Candidate Status</h3>
                    <div className="flex items-center gap-4">
                      <ResponsiveContainer width="50%" height={200}>
                        <PieChart>
                          <Pie data={pieData} cx="50%" cy="50%" outerRadius={70} dataKey="value">
                            {pieData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                          </Pie>
                        </PieChart>
                      </ResponsiveContainer>
                      <div className="space-y-2">
                        {pieData.map((item, i) => (
                          <div key={i} className="flex items-center gap-2">
                            <div className="w-3 h-3 rounded-full" style={{ background: item.color }} />
                            <span className="text-white/70 text-sm">{item.name}</span>
                            <span className="text-white font-semibold text-sm ml-auto">{item.value}%</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Recent Candidates */}
                <div className="glass-card rounded-2xl p-5 border border-white/5">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-white font-semibold">Top Candidates (AI Ranked)</h3>
                    <button className="text-primary-400 text-sm hover:text-primary-300">View all</button>
                  </div>
                  <div className="space-y-3">
                    {candidates.slice(0, 4).map((c, i) => (
                      <div key={i} className="flex items-center gap-4 p-3 rounded-xl hover:bg-white/5 transition-all">
                        <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-primary-500 to-accent-purple flex items-center justify-center text-sm font-bold text-white">
                          {c.name[0]}
                        </div>
                        <div className="flex-1">
                          <p className="text-white text-sm font-medium">{c.name}</p>
                          <p className="text-white/50 text-xs">{c.role}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className={`text-sm font-bold ${c.score >= 85 ? 'text-emerald-400' : c.score >= 70 ? 'text-primary-400' : 'text-yellow-400'}`}>
                            {c.score}%
                          </span>
                          <span className={`badge ${c.status === 'shortlisted' ? 'badge-primary' : c.status === 'hired' ? 'badge-success' : c.status === 'rejected' ? 'badge-danger' : 'badge-warning'} capitalize`}>
                            {c.status}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}

            {/* ---- JOBS ---- */}
            {activeTab === 'jobs' && (
              <motion.div
                key="jobs"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-4"
              >
                <div className="flex items-center justify-between">
                  <p className="text-white/50 text-sm">{myJobs.length} active job postings</p>
                  <button onClick={() => setActiveTab('post')} className="btn-primary text-sm py-2 px-4 flex items-center gap-2">
                    <Plus size={14} /> Post Job
                  </button>
                </div>
                {myJobs.map((job, i) => (
                  <motion.div
                    key={job.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.05 }}
                    className="glass-card rounded-2xl p-5 border border-white/5 hover:border-primary-500/20 transition-all"
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="text-white font-semibold text-lg">{job.title}</h3>
                        <div className="flex items-center gap-4 mt-1 text-white/50 text-sm">
                          <span className="flex items-center gap-1"><Building size={13} /> {job.company}</span>
                          <span className="flex items-center gap-1"><MapPin size={13} /> {job.location}</span>
                          {job.salary && <span className="flex items-center gap-1"><DollarSign size={13} /> {job.salary}</span>}
                        </div>
                        <div className="flex flex-wrap gap-1.5 mt-3">
                          {job.requiredSkills.slice(0, 5).map((skill, j) => (
                            <span key={j} className="px-2 py-0.5 rounded bg-primary-500/10 border border-primary-500/20 text-primary-300 text-xs">
                              {skill}
                            </span>
                          ))}
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="badge-success mb-2 block">Active</span>
                        <p className="text-white/40 text-xs">{Math.floor(Math.random() * 50 + 10)} applicants</p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </motion.div>
            )}

            {/* ---- CANDIDATES ---- */}
            {activeTab === 'candidates' && (
              <motion.div
                key="candidates"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-4"
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className="flex-1 relative">
                    <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/40" />
                    <input className="input-field pl-9 text-sm py-2.5" placeholder="Search candidates..." />
                  </div>
                  <button className="px-4 py-2.5 glass rounded-xl border border-white/10 text-white/60 hover:text-white text-sm flex items-center gap-2">
                    <Filter size={14} /> Filter
                  </button>
                  <button className="px-4 py-2.5 glass rounded-xl border border-white/10 text-white/60 hover:text-white text-sm flex items-center gap-2">
                    <Download size={14} /> Export
                  </button>
                </div>

                <div className="glass-card rounded-2xl border border-white/5 overflow-hidden">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-white/5">
                        <th className="text-left text-white/50 text-xs font-medium px-5 py-3 uppercase tracking-wider">Candidate</th>
                        <th className="text-left text-white/50 text-xs font-medium px-5 py-3 uppercase tracking-wider">Skills</th>
                        <th className="text-left text-white/50 text-xs font-medium px-5 py-3 uppercase tracking-wider">AI Score</th>
                        <th className="text-left text-white/50 text-xs font-medium px-5 py-3 uppercase tracking-wider">Status</th>
                        <th className="text-left text-white/50 text-xs font-medium px-5 py-3 uppercase tracking-wider">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {candidates.map((c, i) => (
                        <motion.tr
                          key={c.id}
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          transition={{ delay: i * 0.05 }}
                          className="border-b border-white/5 hover:bg-white/3 transition-colors"
                        >
                          <td className="px-5 py-3">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary-500 to-accent-purple flex items-center justify-center text-xs font-bold text-white">
                                {c.name[0]}
                              </div>
                              <div>
                                <p className="text-white text-sm font-medium">{c.name}</p>
                                <p className="text-white/40 text-xs">{c.role}</p>
                              </div>
                            </div>
                          </td>
                          <td className="px-5 py-3">
                            <div className="flex flex-wrap gap-1">
                              {c.skills.slice(0, 3).map((skill, j) => (
                                <span key={j} className="px-1.5 py-0.5 rounded bg-white/5 text-white/50 text-xs">{skill}</span>
                              ))}
                            </div>
                          </td>
                          <td className="px-5 py-3">
                            <span className={`font-bold ${c.score >= 85 ? 'text-emerald-400' : c.score >= 70 ? 'text-primary-400' : 'text-yellow-400'}`}>
                              {c.score}%
                            </span>
                          </td>
                          <td className="px-5 py-3">
                            <span className={`badge capitalize ${c.status === 'shortlisted' ? 'badge-primary' : c.status === 'hired' ? 'badge-success' : c.status === 'rejected' ? 'badge-danger' : 'badge-warning'}`}>
                              {c.status}
                            </span>
                          </td>
                          <td className="px-5 py-3">
                            <div className="flex items-center gap-2">
                              <button className="p-1.5 rounded-lg hover:bg-white/10 text-white/40 hover:text-white transition-colors">
                                <Eye size={14} />
                              </button>
                              <button className="p-1.5 rounded-lg hover:bg-emerald-500/20 text-white/40 hover:text-emerald-400 transition-colors">
                                <CheckCircle size={14} />
                              </button>
                              <button className="p-1.5 rounded-lg hover:bg-red-500/20 text-white/40 hover:text-red-400 transition-colors">
                                <XCircle size={14} />
                              </button>
                            </div>
                          </td>
                        </motion.tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </motion.div>
            )}

            {/* ---- POST JOB ---- */}
            {activeTab === 'post' && (
              <motion.div
                key="post"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="max-w-2xl"
              >
                <div className="glass-card rounded-2xl p-6 border border-white/5">
                  <h3 className="text-white font-bold text-xl mb-6">Post a New Job</h3>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-white/70 text-sm font-medium block mb-1.5">Job Title *</label>
                        <input
                          value={newJob.title}
                          onChange={(e) => setNewJob({...newJob, title: e.target.value})}
                          className="input-field"
                          placeholder="e.g. Senior React Engineer"
                        />
                      </div>
                      <div>
                        <label className="text-white/70 text-sm font-medium block mb-1.5">Company *</label>
                        <input
                          value={newJob.company}
                          onChange={(e) => setNewJob({...newJob, company: e.target.value})}
                          className="input-field"
                          placeholder="e.g. Acme Corp"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-white/70 text-sm font-medium block mb-1.5">Job Description</label>
                      <textarea
                        value={newJob.description}
                        onChange={(e) => setNewJob({...newJob, description: e.target.value})}
                        className="input-field h-28 resize-none"
                        placeholder="Describe the role, responsibilities, and your company..."
                      />
                    </div>

                    <div>
                      <label className="text-white/70 text-sm font-medium block mb-1.5">Required Skills (comma-separated)</label>
                      <input
                        value={newJob.requiredSkills}
                        onChange={(e) => setNewJob({...newJob, requiredSkills: e.target.value})}
                        className="input-field"
                        placeholder="React, TypeScript, Node.js, AWS"
                      />
                    </div>

                    <div>
                      <label className="text-white/70 text-sm font-medium block mb-1.5">Preferred Skills (comma-separated)</label>
                      <input
                        value={newJob.preferredSkills}
                        onChange={(e) => setNewJob({...newJob, preferredSkills: e.target.value})}
                        className="input-field"
                        placeholder="GraphQL, Docker, Kubernetes"
                      />
                    </div>

                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <label className="text-white/70 text-sm font-medium block mb-1.5">Experience</label>
                        <input
                          value={newJob.experienceLevel}
                          onChange={(e) => setNewJob({...newJob, experienceLevel: e.target.value})}
                          className="input-field"
                          placeholder="3+ years"
                        />
                      </div>
                      <div>
                        <label className="text-white/70 text-sm font-medium block mb-1.5">Location</label>
                        <input
                          value={newJob.location}
                          onChange={(e) => setNewJob({...newJob, location: e.target.value})}
                          className="input-field"
                          placeholder="Remote / NYC"
                        />
                      </div>
                      <div>
                        <label className="text-white/70 text-sm font-medium block mb-1.5">Salary Range</label>
                        <input
                          value={newJob.salary}
                          onChange={(e) => setNewJob({...newJob, salary: e.target.value})}
                          className="input-field"
                          placeholder="$120k - $160k"
                        />
                      </div>
                    </div>

                    <div className="flex items-center gap-3 pt-2">
                      <motion.button
                        onClick={handlePostJob}
                        className="btn-primary flex items-center gap-2"
                        whileHover={{ scale: 1.02 }}
                      >
                        <Plus size={16} /> Post Job
                      </motion.button>
                      <button
                        onClick={() => setActiveTab('jobs')}
                        className="btn-secondary"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
};

export default RecruiterDashboard;
